import { useState } from "react";
/* Fixed: All ternary operators corrected - deployment cache clear */
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, FileText, MapPin, Calendar } from "lucide-react";
import Footer from "@/components/footer";
import { Deal } from "@shared/schema";

export default function ViewDeals() {
  const [searchTerm, setSearchTerm] = useState("");
  
  // Fetch real deal data from API
  const { data: dealsData, isLoading, error } = useQuery({
    queryKey: ['/api/deals'],
    select: (data: any) => data
  });

  const deals = dealsData?.deals || [];
  const totalDeals = deals.length;

  // Calculate counts for each category based on classification and status
  const unclassifiedCount = deals.filter((deal: Deal) => deal.classification === "unclassified").length;
  const reviewingCount = deals.filter((deal: Deal) => deal.classification === "yellow" || deal.status === "approved").length;
  const passedCount = deals.filter((deal: Deal) => deal.classification === "red" || deal.status === "rejected").length;

  const getStatusColor = (classification: string, status: string) => {
    // YELLOW = REVIEWING (meets criteria)
    if (classification === "yellow" || status === "approved") return "default";
    if (classification === "unclassified") return "secondary";
    // RED = PASSED (does not meet criteria)
    if (classification === "red" || status === "rejected") return "destructive";
    return "secondary";
  };

  const getDisplayStatus = (deal: Deal) => {
    // YELLOW = REVIEWING (meets criteria)
    if (deal.classification === "yellow" || deal.status === "approved") return "REVIEWING";
    // RED = PASSED (does not meet criteria)
    if (deal.classification === "red" || deal.status === "rejected") return "PASSED";
    if (deal.classification === "unclassified") return "Unclassified";
    return "Pending";
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900">View Deals</h1>
            <p className="text-slate-600 mt-2">Loading deals...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-900">View Deals</h1>
            <p className="text-red-600 mt-2">Error loading deals. Please try again.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">View Deals</h1>
          <p className="text-slate-600 mt-2">Browse and review all submitted deals</p>
        </div>

        <Tabs defaultValue="all" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all" data-testid="button-all">ALL ({totalDeals})</TabsTrigger>
            <TabsTrigger value="pending" data-testid="button-unclassified">UNCLASSIFIED ({unclassifiedCount})</TabsTrigger>
            <TabsTrigger value="approved" data-testid="button-approved">REVIEWING ({reviewingCount})</TabsTrigger>
            <TabsTrigger value="rejected" data-testid="button-rejected">PASSED ({passedCount})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>All Deals</CardTitle>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search deals..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {deals.map((deal: Deal) => (
                    <div key={deal.id} className="p-4 border rounded-lg hover:bg-gray-50" data-testid={`deal-${deal.id}`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <h4 className="font-medium">{deal.address || 'Address not provided'}</h4>
                          </div>
                          
                          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm text-muted-foreground">
                            <div>
                              <span className="font-medium">Broker:</span> {deal.broker?.firstName && deal.broker?.lastName ? `${deal.broker.firstName} ${deal.broker.lastName}` : 'N/A'}
                            </div>
                            <div>
                              <span className="font-medium">Value:</span> {deal.askingPrice ? formatCurrency(Number(deal.askingPrice)) : "TBD"}
                            </div>
                            <div>
                              <span className="font-medium">Size:</span> {deal.sizeAcres ? `${deal.sizeAcres} acres` : 'TBD'}
                            </div>
                            <div>
                              <span className="font-medium">QCT:</span> {deal.qctStatus === 'YES' ? <Badge variant="outline" className="bg-green-50 text-green-700">YES</Badge> : deal.qctStatus === 'NO' ? <Badge variant="outline" className="bg-gray-50 text-gray-700">NO</Badge> : 'N/A'}
                            </div>
                            <div className="flex items-center">
                              <Calendar className="h-3 w-3 mr-1" />
                              {deal.createdAt ? new Date(deal.createdAt).toLocaleDateString() : 'N/A'}
                            </div>
                          </div>
                          {deal.comparableCount !== undefined && deal.comparableCount !== null && (
                            <div className="mt-2 text-sm text-muted-foreground">
                              <span className="font-medium">Comparables:</span> {deal.comparableCount} found
                              {deal.comparableNotes && (
                                <span className={`ml-2 text-xs ${
                                  deal.comparableNotes.toLowerCase().includes('error') || 
                                  deal.comparableNotes.toLowerCase().includes('unavailable') ||
                                  deal.comparableNotes.toLowerCase().includes('failed')
                                    ? 'text-amber-600 font-medium'
                                    : ''
                                }`}>
                                  {deal.comparableNotes.toLowerCase().includes('error') || 
                                   deal.comparableNotes.toLowerCase().includes('unavailable') ||
                                   deal.comparableNotes.toLowerCase().includes('failed')
                                    ? '⚠️ ' : ''}
                                  ({deal.comparableNotes})
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          <Badge variant={getStatusColor(deal.classification || '', deal.status || '')} data-testid={`status-${deal.id}`}>
                            {getDisplayStatus(deal)}
                          </Badge>
                          <Button variant="outline" size="sm" data-testid={`button-view-${deal.id}`}>
                            <FileText className="h-4 w-4 mr-1" />
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                  {deals.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      No deals found.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="pending">
            <Card>
              <CardHeader>
                <CardTitle>Unclassified Deals</CardTitle>
                <p className="text-sm text-muted-foreground">Deals currently being evaluated</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {deals.filter((deal: Deal) => deal.classification === "unclassified").map((deal: Deal) => (
                    <div key={deal.id} className="p-4 border rounded-lg" data-testid={`unclassified-deal-${deal.id}`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <h4 className="font-medium">{deal.address || 'Address not provided'}</h4>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm text-muted-foreground">
                            <div>
                              <span className="font-medium">Broker:</span> {deal.broker?.firstName && deal.broker?.lastName ? `${deal.broker.firstName} ${deal.broker.lastName}` : 'N/A'}
                            </div>
                            <div>
                              <span className="font-medium">Value:</span> {deal.askingPrice ? formatCurrency(Number(deal.askingPrice)) : "TBD"}
                            </div>
                            <div>
                              <span className="font-medium">Size:</span> {deal.sizeAcres ? `${deal.sizeAcres} acres` : 'TBD'}
                            </div>
                            <div>
                              <span className="font-medium">QCT:</span> {deal.qctStatus === 'YES' ? <Badge variant="outline" className="bg-green-50 text-green-700">YES</Badge> : deal.qctStatus === 'NO' ? <Badge variant="outline" className="bg-gray-50 text-gray-700">NO</Badge> : 'N/A'}
                            </div>
                            <div className="flex items-center">
                              <Calendar className="h-3 w-3 mr-1" />
                              {deal.createdAt ? new Date(deal.createdAt).toLocaleDateString() : 'N/A'}
                            </div>
                          </div>
                          {deal.comparableCount !== undefined && deal.comparableCount !== null && (
                            <div className="mt-2 text-sm text-muted-foreground">
                              <span className="font-medium">Comparables:</span> {deal.comparableCount} found
                              {deal.comparableNotes && (
                                <span className={`ml-2 text-xs ${
                                  deal.comparableNotes.toLowerCase().includes('error') || 
                                  deal.comparableNotes.toLowerCase().includes('unavailable') ||
                                  deal.comparableNotes.toLowerCase().includes('failed')
                                    ? 'text-amber-600 font-medium'
                                    : ''
                                }`}>
                                  {deal.comparableNotes.toLowerCase().includes('error') || 
                                   deal.comparableNotes.toLowerCase().includes('unavailable') ||
                                   deal.comparableNotes.toLowerCase().includes('failed')
                                    ? '⚠️ ' : ''}
                                  ({deal.comparableNotes})
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center space-x-3">
                          <Badge variant="secondary">Unclassified</Badge>
                          <Button variant="outline" size="sm" data-testid={`button-view-unclassified-${deal.id}`}>
                            <FileText className="h-4 w-4 mr-1" />
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                  {deals.filter((deal: Deal) => deal.classification === "unclassified").length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      No unclassified deals found.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="approved">
            <Card>
              <CardHeader>
                <CardTitle>Reviewing Deals</CardTitle>
                <p className="text-sm text-muted-foreground">Deals that meet criteria and are under review</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {deals.filter((deal: Deal) => deal.status === "approved" || deal.classification === "yellow").map((deal: Deal) => (
                    <div key={deal.id} className="p-4 border rounded-lg bg-yellow-50" data-testid={`approved-deal-${deal.id}`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <h4 className="font-medium">{deal.address || 'Address not provided'}</h4>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm text-muted-foreground">
                            <div>
                              <span className="font-medium">Broker:</span> {deal.broker?.firstName && deal.broker?.lastName ? `${deal.broker.firstName} ${deal.broker.lastName}` : 'N/A'}
                            </div>
                            <div>
                              <span className="font-medium">Value:</span> {deal.askingPrice ? formatCurrency(Number(deal.askingPrice)) : "TBD"}
                            </div>
                            <div>
                              <span className="font-medium">Size:</span> {deal.sizeAcres ? `${deal.sizeAcres} acres` : 'TBD'}
                            </div>
                            <div>
                              <span className="font-medium">QCT:</span> {deal.qctStatus === 'YES' ? <Badge variant="outline" className="bg-green-50 text-green-700">YES</Badge> : deal.qctStatus === 'NO' ? <Badge variant="outline" className="bg-gray-50 text-gray-700">NO</Badge> : 'N/A'}
                            </div>
                            <div className="flex items-center">
                              <Calendar className="h-3 w-3 mr-1" />
                              {deal.createdAt ? new Date(deal.createdAt).toLocaleDateString() : 'N/A'}
                            </div>
                          </div>
                          {deal.comparableCount !== undefined && deal.comparableCount !== null && (
                            <div className="mt-2 text-sm text-muted-foreground">
                              <span className="font-medium">Comparables:</span> {deal.comparableCount} found
                              {deal.comparableNotes && (
                                <span className={`ml-2 text-xs ${
                                  deal.comparableNotes.toLowerCase().includes('error') || 
                                  deal.comparableNotes.toLowerCase().includes('unavailable') ||
                                  deal.comparableNotes.toLowerCase().includes('failed')
                                    ? 'text-amber-600 font-medium'
                                    : ''
                                }`}>
                                  {deal.comparableNotes.toLowerCase().includes('error') || 
                                   deal.comparableNotes.toLowerCase().includes('unavailable') ||
                                   deal.comparableNotes.toLowerCase().includes('failed')
                                    ? '⚠️ ' : ''}
                                  ({deal.comparableNotes})
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center space-x-3">
                          <Badge variant="default">REVIEWING</Badge>
                          <Button variant="outline" size="sm" data-testid={`button-view-approved-${deal.id}`}>
                            <FileText className="h-4 w-4 mr-1" />
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                  {deals.filter((deal: Deal) => deal.status === "approved" || deal.classification === "yellow").length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      No deals under review found.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="rejected">
            <Card>
              <CardHeader>
                <CardTitle>Passed Deals</CardTitle>
                <p className="text-sm text-muted-foreground">Deals that did not meet criteria</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {deals.filter((deal: Deal) => deal.status === "rejected" || deal.classification === "red").map((deal: Deal) => (
                    <div key={deal.id} className="p-4 border rounded-lg bg-red-50" data-testid={`rejected-deal-${deal.id}`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <h4 className="font-medium">{deal.address || 'Address not provided'}</h4>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm text-muted-foreground">
                            <div>
                              <span className="font-medium">Broker:</span> {deal.broker?.firstName && deal.broker?.lastName ? `${deal.broker.firstName} ${deal.broker.lastName}` : 'N/A'}
                            </div>
                            <div>
                              <span className="font-medium">Value:</span> {deal.askingPrice ? formatCurrency(Number(deal.askingPrice)) : "TBD"}
                            </div>
                            <div>
                              <span className="font-medium">Size:</span> {deal.sizeAcres ? `${deal.sizeAcres} acres` : 'TBD'}
                            </div>
                            <div>
                              <span className="font-medium">QCT:</span> {deal.qctStatus === 'YES' ? <Badge variant="outline" className="bg-green-50 text-green-700">YES</Badge> : deal.qctStatus === 'NO' ? <Badge variant="outline" className="bg-gray-50 text-gray-700">NO</Badge> : 'N/A'}
                            </div>
                            <div className="flex items-center">
                              <Calendar className="h-3 w-3 mr-1" />
                              {deal.createdAt ? new Date(deal.createdAt).toLocaleDateString() : 'N/A'}
                            </div>
                          </div>
                          {deal.comparableCount !== undefined && deal.comparableCount !== null && (
                            <div className="mt-2 text-sm text-muted-foreground">
                              <span className="font-medium">Comparables:</span> {deal.comparableCount} found
                              {deal.comparableNotes && (
                                <span className={`ml-2 text-xs ${
                                  deal.comparableNotes.toLowerCase().includes('error') || 
                                  deal.comparableNotes.toLowerCase().includes('unavailable') ||
                                  deal.comparableNotes.toLowerCase().includes('failed')
                                    ? 'text-amber-600 font-medium'
                                    : ''
                                }`}>
                                  {deal.comparableNotes.toLowerCase().includes('error') || 
                                   deal.comparableNotes.toLowerCase().includes('unavailable') ||
                                   deal.comparableNotes.toLowerCase().includes('failed')
                                    ? '⚠️ ' : ''}
                                  ({deal.comparableNotes})
                                </span>
                              )}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center space-x-3">
                          <Badge variant="destructive">PASSED</Badge>
                          <Button variant="outline" size="sm" data-testid={`button-view-rejected-${deal.id}`}>
                            <FileText className="h-4 w-4 mr-1" />
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                  {deals.filter((deal: Deal) => deal.status === "rejected" || deal.classification === "red").length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      No passed deals found.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        <Footer />
    </div>
    </div>
  );
}