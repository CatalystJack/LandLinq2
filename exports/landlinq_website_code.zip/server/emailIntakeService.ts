/**
 * Email Intake Service
 * Processes inbound deal emails → AI parse → review queue.
 * Nothing auto-creates a deal. Analyst must approve each item.
 *
 * CONTINUOUS LEARNING:
 * Every analyst correction becomes a training signal.
 * Approved examples are injected as few-shot context into future parses,
 * making the AI progressively more accurate over time.
 */

import { db } from './db.js';
import { emailIntakeQueue, emailIntakeTrainingExamples } from '../shared/schema.js';
import { eq, desc, and, sql } from 'drizzle-orm';
import { apiCallTracker } from './apiCallTracker.js';
import { simpleParser } from 'mailparser';

// ── Types ────────────────────────────────────────────────────────────────────

interface RawEmail {
  from: string;
  to: string;
  subject?: string;
  text?: string;
  html?: string;
  replyTo?: string;
  attachments?: Array<{
    filename: string;
    contentType: string;
    content?: string;
    url?: string;
  }>;
  envelope?: string;
}

interface ParsedFields {
  dealType?: 'land_development' | 'existing_multifamily' | 'unknown';
  propertyName?: string;
  address?: string;
  city?: string;
  state?: string;
  zip?: string;
  acres?: number;
  price?: number;
  unitCount?: number;
  vintage?: number;
  brokerName?: string;
  brokerEmail?: string;
  brokerPhone?: string;
  notes?: string;
  zoning?: string;
}

interface FieldConfidences {
  address: number;
  city: number;
  state: number;
  zip: number;
  acres: number;
  price: number;
  unitCount: number;
  vintage: number;
}

interface ParseResult {
  fields: ParsedFields;
  confidences: FieldConfidences;
  overallConfidence: number;
}

// ── Main Service Class ───────────────────────────────────────────────────────

export class EmailIntakeService {

  /**
   * Primary entry point — called by the /api/inbound-email webhook.
   */
  static async processInboundEmail(rawBody: any): Promise<{ intakeId: string } | null> {
    const email = await EmailIntakeService.extractEmailFields(rawBody);
    if (!email) return null;

    console.log(`📧 [INTAKE] Processing email from ${email.from} — "${email.subject}"`);

    // Loop prevention
    const fromLower = email.from.toLowerCase();
    if (['@landlinq.ai', 'catalyst.landlinq.ai'].some(d => fromLower.includes(d))) {
      console.log(`🔄 [INTAKE] Blocked — loop prevention`);
      return null;
    }

    // Recipient check
    let envelopeTo = '';
    try {
      if (rawBody.envelope) {
        const env = typeof rawBody.envelope === 'string' ? JSON.parse(rawBody.envelope) : rawBody.envelope;
        envelopeTo = (env.to || []).join(',').toLowerCase();
      }
    } catch { /* ignore */ }

    const toField = (email.to || '').toLowerCase();
    const ccField = (rawBody.cc || '').toLowerCase();
    const validRecipient =
      toField.includes('deals@landlinq.ai') ||
      toField.includes('deal@landlinq.ai') ||
      ccField.includes('deals@landlinq.ai') ||
      ccField.includes('deal@landlinq.ai') ||
      envelopeTo.includes('deals@landlinq.ai') ||
      envelopeTo.includes('deal@landlinq.ai') ||
      toField.includes('deals@catalyst.landlinq.ai') ||
      toField.includes('deal@catalyst.landlinq.ai') ||
      envelopeTo.includes('deals@catalyst.landlinq.ai') ||
      envelopeTo.includes('deal@catalyst.landlinq.ai');

    if (!validRecipient) {
      console.log(`📧 [INTAKE] Ignored — not addressed to deal(s)@landlinq.ai`);
      return null;
    }

    // Deduplication
    const crypto = await import('crypto');
    const hashSource = `${email.from}|${email.subject || ''}|${(email.text || '').substring(0, 200)}`;
    const emailHash = crypto.createHash('sha256').update(hashSource).digest('hex');

    const existing = await db.select().from(emailIntakeQueue)
      .where(eq(emailIntakeQueue.emailHash, emailHash)).limit(1);
    if (existing.length > 0) {
      console.log(`⏭️ [INTAKE] Duplicate blocked`);
      return { intakeId: existing[0].id };
    }

    // Attachment text extraction + buffer collection for object storage upload
    let attachmentText = '';
    const attachmentNames: string[] = [];
    // Collect raw buffers alongside text so we can persist them after DB insert
    const attachmentBuffers: Array<{ filename: string; contentType: string; buffer: Buffer }> = [];
    if (email.attachments?.length) {
      for (const att of email.attachments) {
        if (att.filename) attachmentNames.push(att.filename);
        // Collect raw buffer for storage — handles both inline base64 content and URL-based attachments (SendGrid large files)
        try {
          if (att.content) {
            const buf = Buffer.from(att.content, 'base64');
            if (buf.length > 0) {
              attachmentBuffers.push({ filename: att.filename || 'attachment', contentType: att.contentType || 'application/octet-stream', buffer: buf });
            }
          } else if (att.url) {
            // SendGrid delivers large attachments as URLs — fetch and buffer them
            const res = await fetch(att.url, { signal: AbortSignal.timeout(30000) });
            if (res.ok) {
              const arrayBuf = await res.arrayBuffer();
              const buf = Buffer.from(arrayBuf);
              if (buf.length > 0) {
                attachmentBuffers.push({ filename: att.filename || 'attachment', contentType: att.contentType || res.headers.get('content-type') || 'application/octet-stream', buffer: buf });
              }
            } else {
              console.warn(`⚠️ [INTAKE] URL attachment fetch failed (${res.status}): ${att.filename}`);
            }
          }
        } catch (e) { console.warn(`⚠️ [INTAKE] Buffer collect failed for ${att.filename}:`, e); }
        // Text extraction (existing)
        try {
          if (att.contentType?.includes('pdf') || att.filename?.toLowerCase().endsWith('.pdf')) {
            const t = await EmailIntakeService.extractPdfText(att);
            if (t) attachmentText += `\n\nPDF ATTACHMENT (${att.filename}):\n${t}`;
          } else if (att.contentType?.startsWith('image/')) {
            const t = await EmailIntakeService.describeImageAttachment(att, email.subject);
            if (t) attachmentText += `\n\nIMAGE ATTACHMENT (${att.filename}):\n${t}`;
          }
        } catch (e) { console.warn(`⚠️ [INTAKE] Attachment read failed:`, e); }
      }
    }

    // Follow deal links (package, OM, due diligence) found in the HTML body
    let linkedContent = '';
    if (email.html) {
      try {
        linkedContent = await EmailIntakeService.fetchLinkedPackageContent(email.html);
      } catch (e) {
        console.warn('⚠️ [INTAKE] Link following failed:', e);
      }
    }

    // AI parse with few-shot examples
    const fullText = [email.text || '', attachmentText, linkedContent].filter(Boolean).join('\n\n');
    // Don't pre-seed with internal team emails — forwarders (catalystcp.com, landlinq.ai) are not the broker
    // Also treat distribution list senders (listings@, noreply@, no-reply@, info@, etc.) as non-broker
    const isInternalSender = /(@catalystcp\.com|@landlinq\.ai)/i.test(email.from);
    const isDistributionList = /\b(listings|noreply|no-reply|donotreply|do-not-reply|info|newsletter|updates|notifications|mailer|blast)@/i.test(email.from);
    const useFromAsBroker = !isInternalSender && !isDistributionList;

    // For forwarded emails, pre-extract the original broker's From: line from the body
    // so we can give the AI a reliable, labeled broker email/name rather than hoping
    // it reads forwarding headers correctly.
    const isForwarded = isInternalSender ||
      /^(fwd|fw):/i.test(email.subject || '') ||
      /begin forwarded message|forwarded message|-----original message-----/i.test(fullText);
    const originalSender = isForwarded
      ? EmailIntakeService.extractOriginalSenderFromForwarded(fullText)
      : null;

    if (isForwarded && originalSender) {
      console.log(`📧 [INTAKE] Forwarded email — original broker: ${originalSender.name || '(no name)'} <${originalSender.email || 'unknown'}>`);
    }

    let parseResult: ParseResult = {
      fields: useFromAsBroker ? { brokerEmail: email.from, brokerName: EmailIntakeService.nameFromEmail(email.from) } : {},
      confidences: { address: 0, city: 0, state: 0, zip: 0, acres: 0, price: 0, unitCount: 0, vintage: 0 },
      overallConfidence: 0,
    };
    try {
      parseResult = await EmailIntakeService.aiParseEmail(fullText, email.from, email.subject, email.replyTo, isForwarded, originalSender);
    } catch (e) {
      console.error('❌ [INTAKE] AI parse failed:', e);
    }

    // Save to queue
    const [row] = await db.insert(emailIntakeQueue).values({
      fromEmail: email.from,
      fromName: EmailIntakeService.nameFromEmail(email.from),
      subject: email.subject || '(No Subject)',
      emailBody: email.text || '',
      emailHtml: email.html || '',
      emailHash,
      attachmentCount: email.attachments?.length ?? 0,
      attachmentNames: attachmentNames.length > 0 ? attachmentNames : [],
      parsedDealType: parseResult.fields.dealType ?? 'unknown',
      parsedPropertyName: parseResult.fields.propertyName ?? null,
      parsedAddress: parseResult.fields.address ?? null,
      parsedCity: parseResult.fields.city ?? null,
      parsedState: parseResult.fields.state ?? null,
      parsedZip: parseResult.fields.zip ?? null,
      parsedAcres: parseResult.fields.acres != null ? String(parseResult.fields.acres) : null,
      parsedPrice: parseResult.fields.price ?? null,
      parsedUnitCount: parseResult.fields.unitCount ?? null,
      parsedVintage: parseResult.fields.vintage ?? null,
      parsedBrokerName: parseResult.fields.brokerName ?? null,
      parsedBrokerEmail: parseResult.fields.brokerEmail ?? null,
      parsedBrokerPhone: parseResult.fields.brokerPhone ?? null,
      parsedNotes: parseResult.fields.notes ?? null,
      parsedZoning: parseResult.fields.zoning ?? null,
      overallConfidence: String(parseResult.overallConfidence),
      fieldConfidences: parseResult.confidences as any,
      status: 'pending',
    }).returning();

    // Upload all attachment buffers to object storage now that we have the intake ID
    if (attachmentBuffers.length > 0) {
      try {
        const { ObjectStorageService } = await import('./objectStorage.js');
        const storageService = new ObjectStorageService();
        const storedFiles: Array<{ filename: string; objectPath: string; contentType: string; sizeBytes: number }> = [];
        for (const ab of attachmentBuffers) {
          try {
            const objectPath = await storageService.uploadIntakeAttachment(ab.buffer, ab.filename, ab.contentType, row.id);
            storedFiles.push({ filename: ab.filename, objectPath, contentType: ab.contentType, sizeBytes: ab.buffer.length });
          } catch (uploadErr) {
            console.warn(`⚠️ [INTAKE] Failed to upload ${ab.filename}:`, uploadErr);
          }
        }
        if (storedFiles.length > 0) {
          await db.execute(sql`
            UPDATE email_intake_queue
            SET attachment_files = ${JSON.stringify(storedFiles)}::jsonb
            WHERE id = ${row.id}
          `);
          console.log(`📎 [INTAKE] Stored ${storedFiles.length} attachment(s) for intake ${row.id}`);
        }
      } catch (storageErr) {
        console.warn('⚠️ [INTAKE] Object storage upload skipped (not configured?):', (storageErr as Error).message);
      }
    }

    console.log(`✅ [INTAKE] Saved: ${row.id} (confidence ${parseResult.overallConfidence}%)`);
    return { intakeId: row.id };
  }

  // ── Extract original sender from a forwarded email body ─────────────────

  /**
   * When a team member forwards a broker email, the body contains forwarding
   * headers that include the ORIGINAL From: line. Extract name + email from it.
   *
   * Handles patterns like:
   *   "---------- Forwarded message ---------\nFrom: Jay Smith <jay@broker.com>"
   *   "-----Original Message-----\nFrom: Jay Smith [mailto:jay@broker.com]"
   *   "Begin forwarded message:\nFrom: Jay Smith <jay@broker.com>"
   */
  static extractOriginalSenderFromForwarded(text: string): { name: string | null; email: string | null } | null {
    if (!text) return null;

    // Locate any forwarding header block
    const fwdMarkerRe = /(?:[-─]{3,}\s*(?:forwarded message|original message|begin forwarded message)[^]*?[-─]{0,3}|begin forwarded message\s*:?\s*)/i;
    const markerMatch = fwdMarkerRe.exec(text);
    // Search in a window: either after the marker or in the first 3000 chars
    const searchStart = markerMatch ? markerMatch.index + markerMatch[0].length : 0;
    const searchText = text.substring(searchStart, searchStart + 3000);

    // Pattern 1: From: Name <email@example.com>
    const angleMatch = /^From:\s*(.+?)\s*<([^>@]+@[^>]+)>/im.exec(searchText);
    if (angleMatch) {
      const name = angleMatch[1].replace(/"/g, '').trim() || null;
      const email = angleMatch[2].trim();
      return { name, email };
    }

    // Pattern 2: From: Name [mailto:email@example.com]
    const mailtoMatch = /^From:\s*(.+?)\s*\[mailto:([^\]@]+@[^\]]+)\]/im.exec(searchText);
    if (mailtoMatch) {
      return { name: mailtoMatch[1].trim() || null, email: mailtoMatch[2].trim() };
    }

    // Pattern 3: From: email@example.com (plain email, no display name)
    const plainMatch = /^From:\s*([^\s@<]+@[^\s>]+)/im.exec(searchText);
    if (plainMatch) {
      return { name: null, email: plainMatch[1].trim() };
    }

    return null;
  }

  // ── GPT-4o structured parser with few-shot injection ─────────────────────

  private static async aiParseEmail(
    text: string,
    fromEmail: string,
    subject?: string,
    replyTo?: string,
    isForwarded?: boolean,
    originalSender?: { name: string | null; email: string | null } | null
  ): Promise<ParseResult> {
    const OpenAI = (await import('openai')).default;
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    // Pull up to 5 curated training examples to inject as few-shot context
    const fewShotBlock = await EmailIntakeService.buildFewShotBlock();

    const replyToLine = replyTo ? `REPLY-TO: ${replyTo}` : '';

    // Build forwarded-email header block for the prompt
    let forwardedSenderBlock = '';
    if (isForwarded) {
      if (originalSender?.email) {
        forwardedSenderBlock = `⚠️ FORWARDED EMAIL — the FROM address above is a Catalyst Capital team member who forwarded this email. They are NOT the broker.
ORIGINAL BROKER EMAIL (pre-extracted from forwarding headers): ${originalSender.email}${originalSender.name ? ` (${originalSender.name})` : ''}
Use this as brokerEmail and brokerName — do NOT use the FROM address.`;
      } else {
        forwardedSenderBlock = `⚠️ FORWARDED EMAIL — the FROM address above is a Catalyst Capital team member who forwarded this email. They are NOT the broker.
Find the original broker's name and email from the forwarded email body (sign-off like "Best, Jay", signature block, or "From: Name <email>" in the forwarding headers).`;
      }
    }

    const prompt = `You are a real estate deal analyst. Extract property information from this broker email.
Return ONLY valid JSON matching the exact schema below.
${fewShotBlock}
EMAIL FROM: ${fromEmail}
${replyToLine}
${forwardedSenderBlock}
SUBJECT: ${subject || '(none)'}

EMAIL CONTENT:
${text.substring(0, 12000)}

Return this exact JSON structure:
{
  "dealType": "land_development" if this is raw/vacant land being sold for future development, OR "existing_multifamily" if this is an existing apartment complex/multifamily property for sale, OR "unknown" if unclear,
  "propertyName": the explicitly named listing or project name as written in the email subject or body headline (e.g. "Jacksonville Southbank Riverwalk Redevelopment Site", "Eastwood Village Phase 2"). Use the name exactly as written. Return null only if NO name is given. NEVER copy names from training examples — use only what appears in THIS email.,
  "address": the explicit street address (number + street name) verbatim from THIS email's subject or body (e.g. "8638 Valley Falls Road", "304 S Scientific Street", "1200 Riverplace Blvd"). Common patterns: "1234 Street Name [—|-|,] City, ST ZIP", or address in the email subject line. If no street number/name exists, use a named intersection (e.g. "10th Ave & Lea Ave"). If only a project/landmark name exists with NO street address, return null. NEVER use a submarket/region/market description. NEVER include city/state/zip here. NEVER use an address from a training example.,
  "city": "city name — explicitly stated in THIS email OR inferred from a named neighborhood/district/landmark you recognize. For portfolio deals: use the city where the PRIMARY property is located. Never use a region or submarket name as a city." or null,
  "state": "2-letter US state code" or null,
  "zip": "5-digit ZIP code — look for it after city/state in address lines like 'Boiling Springs, SC 29316'. Extract it if present." or null,
  "acres": number — look for patterns like "19.7 acres", "~19.7 acres", "(~19.7 acres)", "±20 acres", "12.5 ac". The ~ and ± symbols mean 'approximately' — still extract the number. NEVER invent or estimate acreage. or null,
  "price": number in whole dollars — ONLY if a specific dollar amount is explicitly stated as the ASKING or LIST price for the property (e.g. "$4,500,000", "asking $2.1M"). NEVER guess, infer, or use income/rent figures as the price. If no asking price is stated, return null.,
  "unitCount": integer — VERY IMPORTANT: look for patterns like "306-unit", "306 units", "306 apartments", "approved for 306 units", "entitled for 274 apartment units". Extract the number. For land/development deals, look for approved or entitled unit counts. or null,
  "vintage": for a single year use that year; for MULTIPLE years (e.g. "1985, 1987 & 1989") use the MOST RECENT year (1989); 4-digit integer or null,
  "brokerName": the name of the person who WROTE the email or signed it. Check in this order: (1) sign-off at bottom of email body ("Best, Jay" → "Jay"; "Thanks, John Smith" → "John Smith"; "Sincerely, [Name]" → that name), (2) signature block in body, (3) REPLY-TO name. For forwarded emails: ignore the forwarding person entirely — use the ORIGINAL author's sign-off/signature. NEVER use an @catalystcp.com or @landlinq.ai person. or null,
  "brokerEmail": the primary/first broker's email. Priority order: (1) email from the signature block in the body, (2) REPLY-TO addresses, (3) FROM address only if it is a real person (not a distribution list). NEVER use @catalystcp.com or @landlinq.ai. or null,
  "brokerPhone": phone number from the primary broker's signature or null,
  "notes": "2-4 sentence summary of key deal details: entitlement status, approved unit count, value-add opportunity, renovation status, NOI/rent premium potential, proximity to major employment/highways, supply constraints, or other notable deal terms." or null,
  "zoning": "zoning code or description" or null,
  "confidences": {
    "address": 0-100,
    "city": 0-100,
    "state": 0-100,
    "zip": 0-100,
    "acres": 0-100,
    "price": 0-100,
    "unitCount": 0-100,
    "vintage": 0-100
  }
}

CRITICAL RULES:
- EVERY field must come VERBATIM from THIS email. NEVER use values from training examples. NEVER invent or hallucinate any field — return null if not in the email.
- FORWARDED EMAILS: If the subject starts with "Fwd:" or "Fw:" or the body contains "Begin forwarded message" or "Forwarded message", the forwarding person is NEVER the broker. Extract broker info from the body of the forwarded email (sign-off, signature block, REPLY-TO).
- address: ONLY a street number + street name from THIS email. Common address line format: "1234 Street Name — City, ST ZIP (~X acres)" — the address is just "1234 Street Name", city/state/zip/acres go in their own fields. NEVER use a project description, submarket name, or any address from a training example.
- ZIP code: explicitly look for 5-digit codes in address lines. "Boiling Springs, SC 29316" → zip = "29316".
- acres: "~19.7 acres" → 19.7. "(~19.7 acres)" → 19.7. "±20 ac" → 20. The ~ and ± are approximation symbols, not negatives — extract the number.
- unitCount: "306-unit multifamily" → 306. "approved for 274 apartment units" → 274. Look in BOTH the subject line and body.
- price: if the email does NOT explicitly state an asking or list price, return null. Do NOT use rent figures, valuations, or any other dollar amounts.
- brokerName: if the email ends with "Best, Jay" or "Thanks, Jay" or "Sincerely, Jay", brokerName = "Jay". If the email ends with "Best, Jay Smith", brokerName = "Jay Smith".
- state: must be a valid 2-letter US state code (NC, SC, GA, FL, TX, TN, etc.)
- brokerEmail: NEVER @catalystcp.com or @landlinq.ai
- confidence: 100 = explicitly stated verbatim, 70-90 = inferred from recognized landmark, 40-60 = inferred from context, 0 = null
- If multiple properties: extract the FIRST/PRIMARY one`;

    const startTime = Date.now();
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: 'You are a real estate data extraction expert that always responds with valid JSON only. Never add explanations outside the JSON. Extract values ONLY from the email provided — never invent or hallucinate values.' },
        { role: 'user', content: prompt },
      ],
      response_format: { type: 'json_object' },
      temperature: 0,
      max_tokens: 1500,
    });
    apiCallTracker.logCall('OpenAI', 'email_intake_parse', true, Date.now() - startTime);

    const raw = JSON.parse(response.choices[0].message.content || '{}');
    const confs = raw.confidences || {};
    const confidences: FieldConfidences = {
      address: Number(confs.address) || 0,
      city: Number(confs.city) || 0,
      state: Number(confs.state) || 0,
      zip: Number(confs.zip) || 0,
      acres: Number(confs.acres) || 0,
      price: Number(confs.price) || 0,
      unitCount: Number(confs.unitCount) || 0,
      vintage: Number(confs.vintage) || 0,
    };
    const keyConfs = [confidences.address, confidences.city, confidences.state];
    const overallConfidence = Math.round(keyConfs.reduce((a, b) => a + b, 0) / keyConfs.length);

    return {
      fields: {
        dealType: ['land_development', 'existing_multifamily', 'unknown'].includes(raw.dealType) ? raw.dealType : 'unknown',
        propertyName: raw.propertyName || undefined,
        address: raw.address || undefined,
        city: raw.city || undefined,
        state: raw.state || undefined,
        zip: raw.zip || undefined,
        acres: raw.acres != null ? Number(raw.acres) : undefined,
        price: raw.price != null ? Math.round(Number(raw.price)) : undefined,
        unitCount: raw.unitCount != null ? Number(raw.unitCount) : undefined,
        vintage: raw.vintage != null ? Number(raw.vintage) : undefined,
        brokerName: raw.brokerName || undefined,
        brokerEmail: raw.brokerEmail && !raw.brokerEmail.match(/@catalystcp\.com|@landlinq\.ai/i) ? raw.brokerEmail : undefined,
        brokerPhone: raw.brokerPhone || undefined,
        notes: raw.notes || undefined,
        zoning: raw.zoning || undefined,
      },
      confidences,
      overallConfidence,
    };
  }

  // ── Few-shot context builder ──────────────────────────────────────────────
  // Pulls the most recent curated examples from the training table and formats
  // them as input-output demonstrations for the prompt.

  private static async buildFewShotBlock(): Promise<string> {
    try {
      const examples = await db
        .select()
        .from(emailIntakeTrainingExamples)
        .where(eq(emailIntakeTrainingExamples.useInPrompt, true))
        .orderBy(desc(emailIntakeTrainingExamples.createdAt))
        .limit(5);

      if (examples.length === 0) return '';

      let block = '\n\nLEARNED EXAMPLES — these are real emails our analysts have corrected. Use them as ground truth for how to extract fields:\n\n';
      for (let i = 0; i < examples.length; i++) {
        const ex = examples[i];
        const correctOutput = ex.correctedOutput || ex.parsedOutput;
        const snippet = (ex.emailBody || '').substring(0, 800).replace(/\n{3,}/g, '\n\n');
        block += `=== EXAMPLE ${i + 1} ===\n`;
        block += `Subject: ${ex.subject || '(none)'}\nFrom: ${ex.fromEmail || '(none)'}\n`;
        block += `Email body (truncated):\n${snippet}\n\n`;
        // If analyst corrected the AI, show what was WRONG and what is RIGHT
        if (ex.correctedOutput && ex.parsedOutput) {
          const wrong = ex.parsedOutput as any;
          const right = ex.correctedOutput as any;
          const corrections: string[] = [];
          for (const k of Object.keys(right)) {
            if (JSON.stringify(right[k]) !== JSON.stringify((wrong as any)[k]) && right[k] != null) {
              corrections.push(`  "${k}": AI said ${JSON.stringify((wrong as any)[k])} → CORRECT is ${JSON.stringify(right[k])}`);
            }
          }
          if (corrections.length > 0) {
            block += `ANALYST CORRECTIONS (AI was wrong on these fields):\n${corrections.join('\n')}\n`;
          }
        }
        block += `CORRECT JSON OUTPUT: ${JSON.stringify(correctOutput, null, 0)}\n\n`;
      }
      block += '=== END OF EXAMPLES ===\n\n';
      return block;
    } catch (e) {
      console.warn('⚠️ [INTAKE] Could not load few-shot examples:', e);
      return '';
    }
  }

  // ── PDF extraction ───────────────────────────────────────────────────────

  private static async extractPdfText(att: any): Promise<string> {
    let buffer: Buffer;
    if (typeof att.content === 'string') {
      buffer = Buffer.from(att.content, 'base64');
    } else if (Buffer.isBuffer(att.content)) {
      buffer = att.content;
    } else if (att.url) {
      const axios = (await import('axios')).default;
      const resp = await axios.get(att.url, { responseType: 'arraybuffer', timeout: 10000 });
      buffer = Buffer.from(resp.data);
    } else {
      return '';
    }
    const pdfParse = (await import('pdf-parse')).default;
    const data = await pdfParse(buffer);
    return (data.text || '').trim().substring(0, 6000);
  }

  // ── Vision API for image attachments ────────────────────────────────────

  private static async describeImageAttachment(att: any, subject?: string): Promise<string> {
    if (!att.content && !att.url) return '';
    try {
      const OpenAI = (await import('openai')).default;
      const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
      let imageUrl: string;
      if (att.url) {
        imageUrl = att.url;
      } else if (typeof att.content === 'string') {
        imageUrl = `data:${att.contentType || 'image/jpeg'};base64,${att.content}`;
      } else {
        return '';
      }
      const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [{
          role: 'user',
          content: [
            { type: 'text', text: `Real estate deal email attachment (subject: "${subject || 'deal'}"). Extract: address, location, acreage, price, unit count, zoning, broker name/contact. Return as plain text.` },
            { type: 'image_url', image_url: { url: imageUrl, detail: 'high' } },
          ],
        }],
        max_tokens: 500,
      });
      return response.choices[0].message.content || '';
    } catch (e) {
      console.warn('⚠️ [INTAKE-VISION] Failed:', e);
      return '';
    }
  }

  // ── Helpers ──────────────────────────────────────────────────────────────

  /**
   * Extracts email fields from a SendGrid Inbound Parse webhook body.
   * Handles BOTH modes:
   *  - Normal (Send Raw OFF): body has `from`, `to`, `subject`, `text` fields directly.
   *  - Raw MIME (Send Raw ON):  body has a single `email` field with full MIME source.
   */
  private static async extractEmailFields(body: any): Promise<RawEmail | null> {
    if (!body || typeof body !== 'object') return null;

    // ── Raw MIME mode (Send Raw ON in SendGrid) ──────────────────────────────
    if (body.email && typeof body.email === 'string' && !body.from) {
      try {
        const parsed = await simpleParser(body.email);
        const from = parsed.from?.text || '';
        if (!from) return null;

        // Build envelope-like to string from the parsed addresses
        const toAddresses = parsed.to
          ? (Array.isArray(parsed.to) ? parsed.to : [parsed.to])
              .flatMap((a: any) => a.value?.map((v: any) => v.address) || [])
              .join(', ')
          : '';
        const ccAddresses = parsed.cc
          ? (Array.isArray(parsed.cc) ? parsed.cc : [parsed.cc])
              .flatMap((a: any) => a.value?.map((v: any) => v.address) || [])
              .join(', ')
          : '';

        // Build synthetic envelope JSON (so the recipient check works)
        const allTo = [toAddresses, ccAddresses].filter(Boolean).join(', ');
        const syntheticEnvelope = JSON.stringify({
          to: allTo ? [allTo] : [],
          from: parsed.from?.value?.[0]?.address || from,
        });

        // Map attachments from mailparser format
        const attachments: RawEmail['attachments'] = (parsed.attachments || []).map((att: any) => ({
          filename: att.filename || 'attachment',
          contentType: att.contentType || 'application/octet-stream',
          content: att.content ? att.content.toString('base64') : undefined,
        }));

        const replyTo = parsed.replyTo
          ? (Array.isArray(parsed.replyTo) ? parsed.replyTo : [parsed.replyTo])
              .flatMap((a: any) => a.value?.map((v: any) => v.address) || [])
              .filter(Boolean)
              .join(', ')
          : '';

        console.log(`📧 [INTAKE] Parsed raw MIME — from: ${from}, to: ${toAddresses || ccAddresses}${replyTo ? `, reply-to: ${replyTo}` : ''}`);

        return {
          from,
          to: toAddresses,
          subject: parsed.subject || '',
          text: parsed.text || '',
          html: parsed.html || '',
          replyTo: replyTo || undefined,
          attachments,
          envelope: syntheticEnvelope,
        };
      } catch (err) {
        console.error('❌ [INTAKE] Failed to parse raw MIME email:', err);
        return null;
      }
    }

    // ── Normal (parsed) mode ─────────────────────────────────────────────────
    const from = body.from || '';
    if (!from) return null;
    return {
      from,
      to: body.to || '',
      subject: body.subject || '',
      text: body.text || '',
      html: body.html || '',
      replyTo: body['reply-to'] || body.replyTo || undefined,
      attachments: EmailIntakeService.parseAttachments(body),
      envelope: body.envelope,
    };
  }

  private static parseAttachments(body: any): RawEmail['attachments'] {
    const attachments: RawEmail['attachments'] = [];
    let i = 1;
    while (body[`attachment${i}`]) {
      const att = body[`attachment${i}`];
      attachments.push({
        filename: body['attachment-info']
          ? JSON.parse(body['attachment-info'])[`attachment${i}`]?.filename || `attachment${i}`
          : `attachment${i}`,
        contentType: att.contentType || 'application/octet-stream',
        content: typeof att === 'string' ? att : att.content,
        url: att.url,
      });
      i++;
    }
    if (body.attachments && Array.isArray(body.attachments)) {
      for (const att of body.attachments) {
        attachments.push({
          filename: att.filename || att.name || 'attachment',
          contentType: att.type || att.contentType || 'application/octet-stream',
          content: att.content,
          url: att.url,
        });
      }
    }
    return attachments;
  }

  private static nameFromEmail(email: string): string {
    const nameMatch = email.match(/^([^<]+)<.+>$/);
    if (nameMatch) return nameMatch[1].trim();
    const local = email.split('@')[0];
    return local.replace(/[._]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()).trim();
  }

  // ── Link follower ─────────────────────────────────────────────────────────
  // Extracts deal-relevant links from email HTML (package, OM, due diligence,
  // brochure, flyer), fetches each URL, parses PDF or HTML, and returns the
  // combined text so the AI gets the full package content.

  private static extractDealLinks(html: string): Array<{ url: string; label: string }> {
    if (!html) return [];
    const DEAL_KEYWORDS = /package|due.?diligence|offering.?mem|brochure|flyer|om\b|marketing|property.?info|deal.?room|data.?room|costar|loopnet|crexi/i;
    const SKIP_DOMAINS = /mailto:|landlinq|unsubscribe|google\.com\/maps|linkedin|facebook|twitter|instagram/i;
    const links: Array<{ url: string; label: string }> = [];
    const seen = new Set<string>();
    // Match all <a href="...">text</a> pairs
    const re = /<a[^>]+href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    let m: RegExpExecArray | null;
    while ((m = re.exec(html)) !== null) {
      const url = m[1].trim();
      const label = m[2].replace(/<[^>]+>/g, '').trim();
      if (!url.startsWith('http')) continue;
      if (SKIP_DOMAINS.test(url)) continue;
      if (seen.has(url)) continue;
      if (DEAL_KEYWORDS.test(label) || DEAL_KEYWORDS.test(url)) {
        seen.add(url);
        links.push({ url, label: label || url });
      }
    }
    return links.slice(0, 4); // cap at 4 links to avoid runaway fetching
  }

  private static async fetchLinkedPackageContent(html: string): Promise<string> {
    const links = EmailIntakeService.extractDealLinks(html);
    if (links.length === 0) return '';

    const fetch = (await import('node-fetch')).default;
    const pdfParse = (await import('pdf-parse')).default;
    const results: string[] = [];

    for (const { url, label } of links) {
      try {
        console.log(`🔗 [INTAKE] Fetching linked content: ${label} — ${url}`);
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 10000); // 10s timeout
        const res = await fetch(url, {
          signal: controller.signal as any,
          headers: { 'User-Agent': 'Mozilla/5.0 (compatible; LandLinq/1.0; +https://landlinq.ai)' },
          redirect: 'follow',
        });
        clearTimeout(timer);

        const contentType = res.headers.get('content-type') || '';
        const buf = await res.buffer();

        if (contentType.includes('pdf') || url.toLowerCase().includes('.pdf')) {
          const parsed = await pdfParse(buf);
          const text = parsed.text?.substring(0, 4000).trim();
          if (text) {
            results.push(`\n\nLINKED PACKAGE (${label}):\n${text}`);
            console.log(`✅ [INTAKE] PDF fetched: ${text.length} chars from ${label}`);
          }
        } else if (contentType.includes('html') || contentType.includes('text')) {
          // Strip HTML tags and collapse whitespace
          const text = buf.toString('utf8')
            .replace(/<style[\s\S]*?<\/style>/gi, '')
            .replace(/<script[\s\S]*?<\/script>/gi, '')
            .replace(/<[^>]+>/g, ' ')
            .replace(/\s{2,}/g, ' ')
            .substring(0, 4000)
            .trim();
          if (text) {
            results.push(`\n\nLINKED PAGE (${label}):\n${text}`);
            console.log(`✅ [INTAKE] HTML page fetched: ${text.length} chars from ${label}`);
          }
        }
      } catch (e: any) {
        const reason = e?.name === 'AbortError' ? 'timeout' : e?.message || 'error';
        console.warn(`⚠️ [INTAKE] Link fetch failed (${label}): ${reason}`);
      }
    }
    return results.join('');
  }

  // ── Correction diff helper ───────────────────────────────────────────────
  // Returns which fields the analyst changed and by how much.

  private static computeCorrectionDiff(
    item: any,
    overrides: Record<string, any>
  ): Record<string, { ai: any; analyst: any }> {
    const fieldMap: Record<string, string> = {
      address: 'parsedAddress',
      city: 'parsedCity',
      state: 'parsedState',
      zip: 'parsedZip',
      acres: 'parsedAcres',
      price: 'parsedPrice',
      unitCount: 'parsedUnitCount',
      vintage: 'parsedVintage',
      brokerName: 'parsedBrokerName',
      brokerEmail: 'parsedBrokerEmail',
      brokerPhone: 'parsedBrokerPhone',
      notes: 'parsedNotes',
      zoning: 'parsedZoning',
    };
    const diff: Record<string, { ai: any; analyst: any }> = {};
    for (const [overrideKey, dbColumn] of Object.entries(fieldMap)) {
      if (overrides[overrideKey] !== undefined) {
        const aiVal = item[dbColumn];
        const analystVal = overrides[overrideKey];
        if (String(aiVal ?? '') !== String(analystVal ?? '')) {
          diff[overrideKey] = { ai: aiVal ?? null, analyst: analystVal };
        }
      }
    }
    return diff;
  }

  // ── Approve an intake item and create a deal ─────────────────────────────

  static async approveIntakeItem(
    intakeId: string,
    overrides: Partial<Record<string, any>>,
    reviewerEmail: string
  ): Promise<{ dealId: string }> {
    const [item] = await db.select().from(emailIntakeQueue)
      .where(eq(emailIntakeQueue.id, intakeId)).limit(1);

    if (!item) throw new Error('Intake item not found');
    if (item.status !== 'pending') throw new Error('Item is no longer pending');

    // Compute correction diff — this is our training signal
    const correctionDiff = EmailIntakeService.computeCorrectionDiff(item, overrides);
    const correctionCount = Object.keys(correctionDiff).length;
    const wasFullyCorrect = correctionCount === 0;

    // Merge analyst edits over parsed fields
    const propertyName = overrides.propertyName ?? item.parsedPropertyName ?? '';
    const address    = overrides.address    ?? item.parsedAddress   ?? '';
    const city       = overrides.city       ?? item.parsedCity      ?? '';
    const state      = overrides.state      ?? item.parsedState     ?? '';
    const zip        = overrides.zip        ?? item.parsedZip       ?? '';
    const acres      = overrides.acres      ?? (item.parsedAcres ? Number(item.parsedAcres) : null);
    const price      = overrides.price      ?? item.parsedPrice     ?? null;
    const unitCount  = overrides.unitCount  ?? item.parsedUnitCount ?? null;
    const vintage    = overrides.vintage    ?? item.parsedVintage   ?? null;
    const brokerName = overrides.brokerName ?? item.parsedBrokerName ?? '';
    const brokerEmail = overrides.brokerEmail ?? item.parsedBrokerEmail ?? item.fromEmail;
    const brokerPhone = overrides.brokerPhone ?? item.parsedBrokerPhone ?? '';
    const notes      = overrides.notes      ?? item.parsedNotes     ?? '';
    const zoning     = overrides.zoning     ?? item.parsedZoning    ?? '';

    // Find or create broker
    const { storage } = await import('./storage.js');
    let brokerId: string | null = null;
    try {
      const nameParts = brokerName.trim().split(/\s+/);
      const { broker } = await storage.findOrCreateBroker({
        email: brokerEmail,
        firstName: nameParts[0] || 'Email',
        lastName: nameParts.slice(1).join(' ') || 'Submission',
        phone: brokerPhone || undefined,
      });
      brokerId = broker?.id || null;
    } catch (e) {
      console.warn('⚠️ [INTAKE-APPROVE] Broker find/create failed:', e);
    }

    // Read stored attachment file paths from object storage (saved during intake processing)
    let intakeDocumentUrls: string[] = [];
    try {
      const rawIntake = await db.execute(sql`SELECT attachment_files FROM email_intake_queue WHERE id = ${intakeId}`);
      const attachmentFiles = (rawIntake.rows?.[0] as any)?.attachment_files;
      if (Array.isArray(attachmentFiles) && attachmentFiles.length > 0) {
        intakeDocumentUrls = attachmentFiles.map((f: any) => f.objectPath).filter(Boolean);
        console.log(`📎 [INTAKE-APPROVE] Attaching ${intakeDocumentUrls.length} file(s) to deal`);
      }
    } catch (e) {
      console.warn('⚠️ [INTAKE-APPROVE] Could not read attachment_files:', e);
    }

    // Create deal
    const fullAddress = [address, city, state, zip].filter(Boolean).join(', ');
    const deal = await storage.createDeal({
      propertyName: propertyName || null,
      address: address || fullAddress,
      city: city || null,
      state: state || null,
      zip: zip || null,
      sizeAcres: acres ? String(acres) : null,
      askingPrice: price ? String(price) : null,
      unitCount: unitCount ? String(unitCount) : null,
      vintage: vintage ? String(vintage) : null,
      zoning: zoning || null,
      brokerNotes: notes || null,
      brokerId,
      sourceEmail: item.fromEmail,
      submissionMethod: 'email',
      status: 'pending_info',
      documentUrls: intakeDocumentUrls.length > 0 ? intakeDocumentUrls : undefined,
    } as any);

    // Mark approved + store correction diff
    await db.execute(sql`
      UPDATE email_intake_queue SET
        status = 'approved',
        deal_id = ${deal.id},
        reviewed_at = NOW(),
        reviewed_by = ${reviewerEmail},
        correction_diff = ${JSON.stringify(correctionDiff)}::jsonb,
        correction_count = ${correctionCount},
        is_training_example = ${wasFullyCorrect}
      WHERE id = ${intakeId}
    `);

    // Auto-save as training example if fully correct OR if corrections are made
    // (corrections are the most valuable signal — they teach the AI what it got wrong)
    try {
      const aiOutput = {
        address: item.parsedAddress,
        city: item.parsedCity,
        state: item.parsedState,
        zip: item.parsedZip,
        acres: item.parsedAcres ? Number(item.parsedAcres) : null,
        price: item.parsedPrice,
        unitCount: item.parsedUnitCount,
        vintage: item.parsedVintage,
        brokerName: item.parsedBrokerName,
        brokerEmail: item.parsedBrokerEmail,
        brokerPhone: item.parsedBrokerPhone,
        notes: item.parsedNotes,
        zoning: item.parsedZoning,
      };
      const finalOutput = {
        address, city, state, zip,
        acres: acres ? Number(acres) : null,
        price: price ? Number(price) : null,
        unitCount: unitCount ? Number(unitCount) : null,
        vintage: vintage ? Number(vintage) : null,
        brokerName, brokerEmail, brokerPhone, notes, zoning,
      };

      await db.insert(emailIntakeTrainingExamples).values({
        intakeId,
        emailBody: (item.emailBody || '').substring(0, 4000),
        subject: item.subject,
        fromEmail: item.fromEmail,
        parsedOutput: aiOutput as any,
        correctedOutput: correctionCount > 0 ? finalOutput as any : null,
        label: correctionCount > 0 ? 'correction' : 'positive',
        useInPrompt: true,
        addedBy: reviewerEmail,
      });
      console.log(`📚 [TRAINING] Saved ${correctionCount > 0 ? 'correction' : 'positive'} example from ${intakeId}`);
    } catch (trainingErr) {
      console.warn('⚠️ [TRAINING] Could not save training example:', trainingErr);
    }

    // Queue enrichment job
    try {
      const { backgroundJobs } = await import('../shared/schema.js');
      await db.insert(backgroundJobs).values({
        jobType: 'quick_deal_enrichment',
        payload: { dealId: deal.id, triggerSource: 'email_intake_approve' } as any,
        status: 'pending',
        scheduledFor: new Date(),
        attempts: 0,
        maxAttempts: 3,
      });
    } catch (jobErr) {
      console.warn('⚠️ [INTAKE-APPROVE] Could not queue enrichment job:', jobErr);
    }

    console.log(`✅ [INTAKE-APPROVE] Deal ${deal.id} created — ${correctionCount} AI corrections recorded`);
    return { dealId: deal.id };
  }

  // ── Training data management ─────────────────────────────────────────────

  /** Manually save an approved item as a training example (called from API route). */
  static async saveAsTrainingExample(intakeId: string, addedBy: string): Promise<void> {
    const [item] = await db.select().from(emailIntakeQueue)
      .where(eq(emailIntakeQueue.id, intakeId)).limit(1);
    if (!item) throw new Error('Item not found');

    // Mark it
    await db.execute(sql`
      UPDATE email_intake_queue SET is_training_example = TRUE WHERE id = ${intakeId}
    `);

    // Check if already in training table
    const existing = await db.select().from(emailIntakeTrainingExamples)
      .where(eq(emailIntakeTrainingExamples.intakeId, intakeId)).limit(1);
    if (existing.length > 0) {
      // Update to ensure it's enabled
      await db.update(emailIntakeTrainingExamples)
        .set({ useInPrompt: true })
        .where(eq(emailIntakeTrainingExamples.intakeId, intakeId));
      return;
    }

    await db.insert(emailIntakeTrainingExamples).values({
      intakeId,
      emailBody: (item.emailBody || '').substring(0, 4000),
      subject: item.subject,
      fromEmail: item.fromEmail,
      parsedOutput: {
        address: item.parsedAddress,
        city: item.parsedCity,
        state: item.parsedState,
        zip: item.parsedZip,
        acres: item.parsedAcres ? Number(item.parsedAcres) : null,
        price: item.parsedPrice,
        unitCount: item.parsedUnitCount,
        vintage: item.parsedVintage,
        brokerName: item.parsedBrokerName,
        brokerEmail: item.parsedBrokerEmail,
        brokerPhone: item.parsedBrokerPhone,
        notes: item.parsedNotes,
        zoning: item.parsedZoning,
      } as any,
      label: 'positive',
      useInPrompt: true,
      addedBy,
    });
    console.log(`📚 [TRAINING] Manually saved training example for ${intakeId}`);
  }

  /** Toggle whether an example is used in prompts. */
  static async toggleTrainingExample(exampleId: string, useInPrompt: boolean): Promise<void> {
    await db.update(emailIntakeTrainingExamples)
      .set({ useInPrompt })
      .where(eq(emailIntakeTrainingExamples.id, exampleId));
  }

  /** Aggregate correction stats — which fields does the AI most often get wrong? */
  static async getTrainingStats(): Promise<{
    totalApproved: number;
    totalWithCorrections: number;
    avgCorrectionsPerEmail: number;
    fieldCorrectionRates: Record<string, number>;
    trainingExampleCount: number;
    recentAccuracyTrend: { label: string; accuracy: number }[];
  }> {
    const rows = await db.execute(sql`
      SELECT
        COUNT(*) FILTER (WHERE status = 'approved') AS total_approved,
        COUNT(*) FILTER (WHERE status = 'approved' AND correction_count > 0) AS total_with_corrections,
        COALESCE(AVG(correction_count) FILTER (WHERE status = 'approved'), 0) AS avg_corrections,
        jsonb_agg(correction_diff) FILTER (WHERE status = 'approved' AND correction_diff IS NOT NULL AND correction_diff != '{}'::jsonb) AS all_diffs
      FROM email_intake_queue
    `);

    const trainingCount = await db.execute(sql`
      SELECT COUNT(*) AS cnt FROM email_intake_training_examples WHERE use_in_prompt = TRUE
    `);

    // Recent trend: last 20 approved grouped into batches of 5
    const recentRows = await db.execute(sql`
      SELECT correction_count
      FROM email_intake_queue
      WHERE status = 'approved'
      ORDER BY reviewed_at DESC
      LIMIT 20
    `);

    const row = rows.rows[0] as any;
    const totalApproved = Number(row?.total_approved ?? 0);
    const totalWithCorrections = Number(row?.total_with_corrections ?? 0);
    const avgCorrectionsPerEmail = Number(row?.avg_corrections ?? 0);

    // Compute per-field correction rates
    const fieldCorrectionRates: Record<string, number> = {};
    const allFields = ['address', 'city', 'state', 'zip', 'acres', 'price', 'unitCount', 'vintage', 'brokerName', 'brokerEmail', 'notes', 'zoning'];
    if (row?.all_diffs && Array.isArray(row.all_diffs) && totalApproved > 0) {
      const counts: Record<string, number> = {};
      for (const diff of row.all_diffs) {
        if (!diff) continue;
        for (const field of Object.keys(diff)) {
          counts[field] = (counts[field] || 0) + 1;
        }
      }
      for (const field of allFields) {
        fieldCorrectionRates[field] = totalApproved > 0
          ? Math.round(((counts[field] || 0) / totalApproved) * 100)
          : 0;
      }
    } else {
      for (const field of allFields) fieldCorrectionRates[field] = 0;
    }

    // Build trend: group recent into batches of 5
    const recentCounts = (recentRows.rows as any[]).map(r => Number(r.correction_count ?? 0));
    const recentAccuracyTrend: { label: string; accuracy: number }[] = [];
    for (let i = 0; i < recentCounts.length; i += 5) {
      const batch = recentCounts.slice(i, i + 5);
      const perfectCount = batch.filter(c => c === 0).length;
      const accuracy = Math.round((perfectCount / batch.length) * 100);
      recentAccuracyTrend.unshift({ label: `Last ${i + batch.length}`, accuracy });
    }

    return {
      totalApproved,
      totalWithCorrections,
      avgCorrectionsPerEmail: Math.round(avgCorrectionsPerEmail * 10) / 10,
      fieldCorrectionRates,
      trainingExampleCount: Number((trainingCount.rows[0] as any)?.cnt ?? 0),
      recentAccuracyTrend,
    };
  }
}
