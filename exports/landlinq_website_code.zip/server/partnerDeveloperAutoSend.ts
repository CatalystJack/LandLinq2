import { db } from './db';
import { partnerDevelopers, partnerDeveloperSends } from '../shared/schema';
import { eq, and } from 'drizzle-orm';
import { deals } from '../shared/schema';

// ──────────────────────────────────────────────────────────────────────────────
// Auto-send engine: matches a newly-classified deal against every active
// partner developer whose buy box criteria it satisfies.
//
// NEW BEHAVIOR (outbox queue):
//  - ALL matching active developers → insert a 'pending' record in
//    partner_developer_sends (if no existing record for this dev+deal)
//  - Developers with autoSendEnabled=true → ALSO email immediately and mark 'sent'
//  - Analysts see 'pending' records in the Outbox tab and can edit/send manually
// ──────────────────────────────────────────────────────────────────────────────

export async function autoSendMatchingDeveloperEmails(deal: any): Promise<void> {
  try {
    // Fetch ALL active developers — not filtered by autoSendEnabled
    const developers = await db
      .select()
      .from(partnerDevelopers)
      .where(eq(partnerDevelopers.isActive, true));

    if (!developers.length) {
      console.log('⏭️ [AUTO-SEND] No active partner developers registered');
      return;
    }

    console.log(`🔍 [AUTO-SEND] Checking deal ${deal.id} against ${developers.length} active developers`);

    for (const dev of developers) {
      try {
        if (!doesDealMatchDeveloper(deal, dev)) continue;

        // Check if a record already exists (pending or sent)
        const existing = await db
          .select({ id: partnerDeveloperSends.id, status: partnerDeveloperSends.status })
          .from(partnerDeveloperSends)
          .where(and(
            eq(partnerDeveloperSends.developerId, dev.id),
            eq(partnerDeveloperSends.dealId, deal.id),
          ))
          .limit(1);

        if (existing.length > 0) {
          console.log(`⏭️ [AUTO-SEND] Deal ${deal.id} already queued/sent for ${dev.companyName} (status: ${existing[0].status}), skipping`);
          continue;
        }

        if (dev.autoSendEnabled) {
          // Send immediately + record as 'sent'
          await sendDeveloperDealEmail(deal, dev);
          await db.insert(partnerDeveloperSends).values({
            developerId: dev.id,
            dealId: deal.id,
            classification: deal.classification,
            address: deal.address,
            status: 'sent',
            sentAt: new Date(),
          }).onConflictDoNothing();
          console.log(`✅ [AUTO-SEND] Deal ${deal.id} auto-sent to ${dev.email} (${dev.companyName})`);
        } else {
          // Queue as pending for manual review
          await db.insert(partnerDeveloperSends).values({
            developerId: dev.id,
            dealId: deal.id,
            classification: deal.classification,
            address: deal.address,
            status: 'pending',
            sentAt: null,
          }).onConflictDoNothing();
          console.log(`📥 [AUTO-SEND] Deal ${deal.id} queued (pending) for ${dev.companyName} — manual send required`);
        }
      } catch (devError) {
        console.error(`❌ [AUTO-SEND] Failed for ${dev.companyName}:`, devError);
      }
    }
  } catch (err) {
    console.error('❌ [AUTO-SEND] Outer error:', err);
  }
}

// ── Matching logic (mirrors the routing endpoint in routes.ts) ─────────────

export function doesDealMatchDeveloper(deal: any, dev: any): boolean {
  // State
  if (dev.targetStates?.length) {
    if (!deal.state || !dev.targetStates.includes(deal.state)) return false;
  }

  // Product type overlap
  if (dev.productTypes?.length) {
    const dealTypes: string[] = Array.isArray(deal.productTypes)
      ? deal.productTypes
      : (typeof deal.productTypes === 'string'
          ? (() => { try { return JSON.parse(deal.productTypes); } catch { return []; } })()
          : []);
    const hasOverlap = dev.productTypes.some((pt: string) =>
      dealTypes.some((dt: string) =>
        dt.toLowerCase().includes(pt.toLowerCase().split(' ')[0]) ||
        pt.toLowerCase().includes(dt.toLowerCase().split(' ')[0])
      )
    );
    if (!hasOverlap) return false;
  }

  // Acreage floor
  if (dev.minAcres && deal.sizeAcres) {
    if (parseFloat(deal.sizeAcres) < parseFloat(dev.minAcres)) return false;
  }

  // Unit floor
  if (dev.minUnits && deal.estimatedUnits) {
    if (deal.estimatedUnits < dev.minUnits) return false;
  }

  // Price per acre ceiling
  if (dev.maxAskingPricePerAcre && deal.askingPrice && deal.sizeAcres && parseFloat(deal.sizeAcres) > 0) {
    const pricePerAcre = parseFloat(deal.askingPrice) / parseFloat(deal.sizeAcres);
    if (pricePerAcre > parseFloat(dev.maxAskingPricePerAcre)) return false;
  }

  return true;
}

// ── Email builder ──────────────────────────────────────────────────────────

export async function sendDeveloperDealEmail(deal: any, dev: any, overrides?: { zoning?: string; summary?: string }): Promise<void> {
  const { sendNotificationEmail } = await import('./emailService');

  // ── Core fields ────────────────────────────────────────────────────────────
  const addr = [deal.address, deal.city, deal.state].filter(Boolean).join(', ');
  const locationLine = [deal.county ? `${deal.county} County` : null, deal.state].filter(Boolean).join(', ');
  const size = deal.sizeAcres ? `${parseFloat(deal.sizeAcres).toFixed(2)} acres` : null;
  const price = deal.askingPrice ? `$${parseInt(deal.askingPrice).toLocaleString()}` : null;
  const pricePerAcre = (deal.askingPrice && deal.sizeAcres && parseFloat(deal.sizeAcres) > 0)
    ? `$${Math.round(parseFloat(deal.askingPrice) / parseFloat(deal.sizeAcres)).toLocaleString()}/acre`
    : null;
  const units = deal.estimatedUnits ? `${deal.estimatedUnits} units` : null;
  const vintage = deal.vintage ? `${deal.vintage}` : null;
  const zoningDisplay = overrides?.zoning ?? deal.zoning ?? null;

  const dealProductTypes: string[] = Array.isArray(deal.productTypes)
    ? deal.productTypes
    : (typeof deal.productTypes === 'string'
        ? (() => { try { return JSON.parse(deal.productTypes); } catch { return [deal.productTypes]; } })()
        : []);
  const productTypesDisplay = dealProductTypes.join(', ') || 'N/A';
  const summaryText = overrides?.summary ?? deal.developerSummary ?? null;

  // ── Rent comps ─────────────────────────────────────────────────────────────
  const topRentPerUnit = deal.topRentPerUnit && deal.topRentPerUnit !== '0'
    ? `$${parseFloat(deal.topRentPerUnit).toFixed(0)}/unit`
    : null;
  const avgRentPerUnit = deal.avgRentPerUnit && deal.avgRentPerUnit !== '0'
    ? `$${parseFloat(deal.avgRentPerUnit).toFixed(0)}/unit`
    : null;
  const topRentPSF = deal.topRentPSF && deal.topRentPSF !== '0'
    ? `$${parseFloat(deal.topRentPSF).toFixed(2)}/SF`
    : null;
  const avgRentPSF = deal.avgRentPSF && deal.avgRentPSF !== '0'
    ? `$${parseFloat(deal.avgRentPSF).toFixed(2)}/SF`
    : null;
  const compCount = deal.comparableCount ? `${deal.comparableCount}` : null;


  // ── QCT / OZ / DDA badges ─────────────────────────────────────────────────
  const badgeStyle = (bg: string, color: string) =>
    `display:inline-block;padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;background:${bg};color:${color};`;

  const qctBadge = deal.qctStatus === 'YES'
    ? `<span style="${badgeStyle('#fef9c3','#854d0e')}">🏠 QCT</span>`
    : (deal.qctStatus === 'NO' ? `<span style="${badgeStyle('#f3f4f6','#6b7280')}">QCT: No</span>` : '');

  const ozBadge = deal.ozStatus === 'YES'
    ? `<span style="${badgeStyle('#ede9fe','#5b21b6')}">🌟 Opportunity Zone</span>`
    : (deal.ozStatus === 'NO' ? `<span style="${badgeStyle('#f3f4f6','#6b7280')}">OZ: No</span>` : '');

  const ddaLabel = deal.ddaStatus === 'MDDA' ? 'Metro DDA'
    : deal.ddaStatus === 'NMDDA' ? 'Non-Metro DDA'
    : '';
  const ddaBadge = ddaLabel
    ? `<span style="${badgeStyle('#fce7f3','#9d174d')}">🏙️ ${ddaLabel}</span>`
    : (deal.ddaStatus === 'NO' ? `<span style="${badgeStyle('#f3f4f6','#6b7280')}">DDA: No</span>` : '');

  const nmtcBadge = deal.nmtcStatus === 'YES'
    ? `<span style="${badgeStyle('#ecfdf5','#065f46')}">💰 NMTC</span>`
    : '';

  const badges = [qctBadge, ozBadge, ddaBadge, nmtcBadge].filter(Boolean).join(' ');
  const badgesBlock = badges
    ? `<div style="margin-bottom:20px;display:flex;flex-wrap:wrap;gap:6px;">${badges}</div>`
    : '';

  // ── DDA details row ────────────────────────────────────────────────────────
  const ddaDetails = ddaLabel && (deal.ddaVlil || deal.ddaFmr || deal.ddaLihtcMaxRent)
    ? [
        deal.ddaVlil ? `VLIL: $${parseInt(deal.ddaVlil).toLocaleString()}` : '',
        deal.ddaFmr ? `FMR: $${parseInt(deal.ddaFmr).toLocaleString()}/mo` : '',
        deal.ddaLihtcMaxRent ? `Max LIHTC Rent: $${parseInt(deal.ddaLihtcMaxRent).toLocaleString()}/mo` : '',
      ].filter(Boolean).join(' · ')
    : null;

  // ── Comparable properties table ────────────────────────────────────────────
  let compsTable = '';
  if (deal.comparablesJson) {
    const comps: any[] = Array.isArray(deal.comparablesJson) ? deal.comparablesJson : [];
    if (comps.length > 0) {
      const compRows = comps.slice(0, 10).map((c: any, i: number) => {
        const name = c.name || c.property_name || `Comp ${i + 1}`;
        const compVintage = c.vintage || c.year_built || '—';
        const compUnits = c.units || c.unit_count || '—';
        const dist = c.distance_miles != null ? `${parseFloat(c.distance_miles).toFixed(1)} mi` : (c.distance != null ? `${parseFloat(c.distance).toFixed(1)} mi` : '—');
        const rentPsfVal = c.rent_psf != null ? `$${parseFloat(c.rent_psf).toFixed(2)}` : (c.rentPsf != null ? `$${parseFloat(c.rentPsf).toFixed(2)}` : '—');
        const rentUnit = c.rent_per_unit != null ? `$${parseInt(c.rent_per_unit).toLocaleString()}` : (c.rentPerUnit != null ? `$${parseInt(c.rentPerUnit).toLocaleString()}` : '—');
        const bg = i % 2 === 0 ? '#fff' : '#f9fafb';
        return `<tr style="background:${bg};">
          <td style="padding:7px 8px;font-size:12px;color:#111827;border-bottom:1px solid #f3f4f6;">${name}</td>
          <td style="padding:7px 8px;font-size:12px;color:#374151;text-align:center;border-bottom:1px solid #f3f4f6;">${compVintage}</td>
          <td style="padding:7px 8px;font-size:12px;color:#374151;text-align:center;border-bottom:1px solid #f3f4f6;">${compUnits}</td>
          <td style="padding:7px 8px;font-size:12px;color:#374151;text-align:center;border-bottom:1px solid #f3f4f6;">${dist}</td>
          <td style="padding:7px 8px;font-size:12px;color:#374151;text-align:right;border-bottom:1px solid #f3f4f6;">${rentPsfVal}</td>
          <td style="padding:7px 8px;font-size:12px;color:#374151;text-align:right;border-bottom:1px solid #f3f4f6;">${rentUnit}</td>
        </tr>`;
      }).join('');
      compsTable = `
        <div style="margin-bottom:24px;">
          <p style="margin:0 0 8px;font-size:12px;font-weight:700;color:#07172A;text-transform:uppercase;letter-spacing:0.05em;">📊 Comparable Properties (${comps.length} comps)</p>
          <table style="width:100%;border-collapse:collapse;border:1px solid #e5e7eb;border-radius:6px;overflow:hidden;">
            <thead>
              <tr style="background:#07172A;">
                <th style="padding:8px;font-size:11px;color:#9ab8c4;text-align:left;font-weight:600;">Property</th>
                <th style="padding:8px;font-size:11px;color:#9ab8c4;text-align:center;font-weight:600;">Vintage</th>
                <th style="padding:8px;font-size:11px;color:#9ab8c4;text-align:center;font-weight:600;">Units</th>
                <th style="padding:8px;font-size:11px;color:#9ab8c4;text-align:center;font-weight:600;">Distance</th>
                <th style="padding:8px;font-size:11px;color:#9ab8c4;text-align:right;font-weight:600;">Rent PSF</th>
                <th style="padding:8px;font-size:11px;color:#9ab8c4;text-align:right;font-weight:600;">Rent/Unit</th>
              </tr>
            </thead>
            <tbody>${compRows}</tbody>
          </table>
        </div>`;
    }
  }

  // ── Buy box match reasons ──────────────────────────────────────────────────
  const matchReasons: string[] = [];
  if (dev.targetStates?.length && deal.state) {
    matchReasons.push(`📍 <strong>Location:</strong> ${deal.state} is in your target market${dev.targetStates.length > 1 ? 's' : ''} (${dev.targetStates.join(', ')})`);
  }
  if (dev.productTypes?.length && dealProductTypes.length) {
    const matched = dev.productTypes.filter((pt: string) =>
      dealProductTypes.some((dt: string) =>
        dt.toLowerCase().includes(pt.toLowerCase().split(' ')[0]) ||
        pt.toLowerCase().includes(dt.toLowerCase().split(' ')[0])
      )
    );
    if (matched.length) {
      matchReasons.push(`🏗️ <strong>Product Type:</strong> ${matched.join(', ')} aligns with your buy box`);
    }
  }
  if (dev.minAcres && deal.sizeAcres) {
    matchReasons.push(`📐 <strong>Acreage:</strong> ${parseFloat(deal.sizeAcres).toFixed(2)} ac meets your minimum of ${parseFloat(dev.minAcres).toFixed(2)} ac`);
  }
  if (dev.minUnits && deal.estimatedUnits) {
    matchReasons.push(`🏠 <strong>Units:</strong> ${deal.estimatedUnits} units meets your minimum of ${dev.minUnits}`);
  }
  if (dev.maxAskingPricePerAcre && deal.askingPrice && deal.sizeAcres && parseFloat(deal.sizeAcres) > 0) {
    const ppa = parseFloat(deal.askingPrice) / parseFloat(deal.sizeAcres);
    matchReasons.push(`💰 <strong>Price/Acre:</strong> $${Math.round(ppa).toLocaleString()}/ac is within your ceiling of $${parseInt(dev.maxAskingPricePerAcre).toLocaleString()}/ac`);
  }
  if (dev.qctInterest && deal.qctStatus === 'YES') {
    matchReasons.push(`🏠 <strong>QCT:</strong> Property is in a Qualified Census Tract — matches your affordable housing interest`);
  }

  const matchBlock = matchReasons.length
    ? `<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:16px 20px;margin-bottom:24px;">
        <p style="margin:0 0 10px;font-size:12px;font-weight:700;color:#166534;text-transform:uppercase;letter-spacing:0.05em;">✅ Why This Matches Your Criteria</p>
        <ul style="margin:0;padding:0;list-style:none;">
          ${matchReasons.map(r => `<li style="font-size:13px;color:#374151;line-height:1.6;padding:3px 0;">${r}</li>`).join('')}
        </ul>
      </div>`
    : '';

  // ── Helpers ────────────────────────────────────────────────────────────────
  const row = (label: string, value: string | null, highlight = false) =>
    value
      ? `<tr style="border-bottom:1px solid #f3f4f6;">
          <td style="padding:9px 0;font-size:13px;color:#6b7280;width:42%;vertical-align:top;">${label}</td>
          <td style="padding:9px 0;font-size:13px;color:${highlight ? '#d97706' : '#07172A'};font-weight:${highlight ? '700' : '500'};">${value}</td>
        </tr>`
      : '';

  const sectionHeader = (label: string) =>
    `<p style="margin:20px 0 8px;font-size:12px;font-weight:700;color:#07172A;text-transform:uppercase;letter-spacing:0.05em;border-bottom:2px solid #e5e7eb;padding-bottom:4px;">${label}</p>`;

  const logoUrl = 'https://catalyst.landlinq.ai/assets/landlinq-email-logo.png';

  // ── Action buttons ─────────────────────────────────────────────────────────
  const excelBtn = deal.excelModelUrl
    ? `<a href="${deal.excelModelUrl}" style="display:inline-block;background:#217346;color:#fff;font-size:13px;font-weight:600;padding:10px 20px;border-radius:6px;text-decoration:none;margin-right:10px;margin-bottom:10px;">
        📊 Financial Model (Excel)
      </a>`
    : '';
  const memoBtn = deal.investmentMemoUrl
    ? `<a href="${deal.investmentMemoUrl}" style="display:inline-block;background:#07172A;color:#fff;font-size:13px;font-weight:600;padding:10px 20px;border-radius:6px;text-decoration:none;margin-bottom:10px;">
        📄 Investment Memo (PDF)
      </a>`
    : '';
  const buttonsBlock = (excelBtn || memoBtn)
    ? `<div style="margin-bottom:24px;">${excelBtn}${memoBtn}</div>`
    : '';

  // ── Demographics ───────────────────────────────────────────────────────────
  const hasDemo = deal.censusMedianIncome || deal.censusTotalPopulation || deal.censusRenterRate || deal.censusMedianAge;
  const demoSection = hasDemo
    ? `${sectionHeader('📈 Market Demographics')}
       <table style="width:100%;border-collapse:collapse;margin-bottom:8px;">
         ${deal.censusMedianIncome ? row('Median HH Income', `$${parseInt(deal.censusMedianIncome).toLocaleString()}`) : ''}
         ${deal.censusTotalPopulation ? row('Total Population', parseInt(deal.censusTotalPopulation).toLocaleString()) : ''}
         ${deal.censusRenterRate ? row('Renter Rate', `${parseFloat(deal.censusRenterRate).toFixed(1)}%`) : ''}
         ${deal.censusMedianAge ? row('Median Age', `${parseFloat(deal.censusMedianAge).toFixed(1)} yrs`) : ''}
       </table>`
    : '';

  // ── AI classification notes ────────────────────────────────────────────────
  const classificationNotes = deal.aiExplanatoryNotes
    ? `<div style="background:#fefce8;border-left:4px solid #eab308;border-radius:4px;padding:14px 16px;margin-bottom:20px;">
        <p style="margin:0 0 6px;font-size:12px;font-weight:700;color:#854d0e;text-transform:uppercase;letter-spacing:0.05em;">🤖 AI Classification Notes</p>
        <p style="margin:0;font-size:13px;color:#374151;line-height:1.6;white-space:pre-wrap;">${deal.aiExplanatoryNotes}</p>
      </div>`
    : '';

  // ── Summary block ──────────────────────────────────────────────────────────
  const summaryBlock = summaryText
    ? `<div style="background:#f8fafc;border-left:4px solid #009BA7;border-radius:4px;padding:14px 16px;margin-bottom:20px;">
        <p style="margin:0 0 6px;font-size:12px;font-weight:700;color:#009BA7;text-transform:uppercase;letter-spacing:0.05em;">📝 Deal Summary</p>
        <p style="margin:0;font-size:13px;color:#374151;line-height:1.6;white-space:pre-wrap;">${summaryText}</p>
      </div>`
    : '';

  // ── Classification badge ───────────────────────────────────────────────────
  const classLabel = deal.classification === 'green' ? '✅ High Priority'
    : deal.classification === 'yellow' ? '⚠️ Potential'
    : deal.classification || '';
  const classBg = deal.classification === 'green' ? '#dcfce7' : deal.classification === 'yellow' ? '#fef9c3' : '#f3f4f6';
  const classColor = deal.classification === 'green' ? '#166534' : deal.classification === 'yellow' ? '#854d0e' : '#374151';
  const classBadge = classLabel
    ? `<span style="display:inline-block;padding:3px 12px;border-radius:20px;font-size:12px;font-weight:700;background:${classBg};color:${classColor};margin-bottom:4px;">${classLabel}</span>`
    : '';

  const html = `<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f5f7f9;font-family:Arial,sans-serif;">
  <div style="max-width:660px;margin:32px auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.08);">

    <!-- Header -->
    <div style="background:#07172A;padding:24px 32px;">
      <img src="${logoUrl}" alt="LandLinq" style="height:36px;width:auto;display:block;" />
      <p style="margin:8px 0 0;font-size:13px;color:#9ab8c4;">New Acquisition Opportunity — matched to your buy box</p>
    </div>

    <div style="padding:28px 32px;">

      <!-- Property header -->
      <div style="margin-bottom:20px;">
        ${classBadge}
        <p style="margin:6px 0 2px;font-size:20px;font-weight:700;color:#07172A;">${addr}</p>
        <p style="margin:0;font-size:13px;color:#6b7280;">${locationLine} &nbsp;·&nbsp; ${productTypesDisplay}</p>
      </div>

      <!-- QCT / OZ / DDA badges -->
      ${badgesBlock}

      <!-- Match reasons -->
      ${matchBlock}

      <!-- Action buttons (top) -->
      ${buttonsBlock}

      <!-- Property Details -->
      ${sectionHeader('🏗️ Property Details')}
      <table style="width:100%;border-collapse:collapse;margin-bottom:4px;">
        ${row('Acreage', size)}
        ${row('Asking Price', price)}
        ${row('Price / Acre', pricePerAcre)}
        ${row('Est. Units', units)}
        ${row('Year Built (Vintage)', vintage)}
        ${row('Zoning', zoningDisplay)}
        ${row('Deal Type', deal.dealType ? deal.dealType.charAt(0).toUpperCase() + deal.dealType.slice(1) : null)}
        ${row('Under Contract', deal.underContract ? 'Yes' : null)}
      </table>

      <!-- Rent Comps -->
      ${(topRentPerUnit || topRentPSF) ? sectionHeader('💵 Market Rent Comps') : ''}
      ${(topRentPerUnit || topRentPSF) ? `<table style="width:100%;border-collapse:collapse;margin-bottom:4px;">
        ${row('Top Rent / Unit', topRentPerUnit, true)}
        ${row('Avg Rent / Unit', avgRentPerUnit)}
        ${row('Top Rent PSF', topRentPSF, true)}
        ${row('Avg Rent PSF', avgRentPSF)}
        ${row('# of Comps', compCount)}
      </table>` : ''}

      <!-- Comparable Properties Table -->
      ${compsTable}

      <!-- Affordable Housing Status -->
      ${ddaDetails ? `${sectionHeader('🏠 Affordable Housing Details')}
      <table style="width:100%;border-collapse:collapse;margin-bottom:4px;">
        ${row('DDA Status', ddaLabel || null)}
        ${deal.ddaAreaName ? row('HUD Area', deal.ddaAreaName) : ''}
        ${deal.ddaVlil ? row('Very Low Income Limit (4-Person)', `$${parseInt(deal.ddaVlil).toLocaleString()}`) : ''}
        ${deal.ddaFmr ? row('Fair Market Rent (2-BR)', `$${parseInt(deal.ddaFmr).toLocaleString()}/mo`) : ''}
        ${deal.ddaLihtcMaxRent ? row('Max LIHTC Rent', `$${parseInt(deal.ddaLihtcMaxRent).toLocaleString()}/mo`) : ''}
      </table>` : ''}

      <!-- Demographics -->
      ${demoSection}

      <!-- AI Notes -->
      ${classificationNotes}

      <!-- Summary -->
      ${summaryBlock}

      <hr style="border:none;border-top:1px solid #e5e7eb;margin:4px 0 16px;">
      <p style="margin:0;font-size:13px;color:#374151;line-height:1.6;">
        To discuss this deal or request additional information, please reach out at
        <a href="mailto:deals@landlinq.ai" style="color:#009BA7;">deals@landlinq.ai</a>.
      </p>
    </div>

    <!-- Footer -->
    <div style="background:#07172A;padding:16px 32px;text-align:center;">
      <p style="margin:0;font-size:11px;color:#6b7280;">LandLinq · 1600 Camden Road Suite 200, Charlotte NC 28203</p>
    </div>
  </div>
</body>
</html>`;

  // ── Plain-text fallback ────────────────────────────────────────────────────
  const textMatchLines = matchReasons.map(r => r.replace(/<[^>]+>/g, ''));
  const textLines = [
    `NEW DEAL OPPORTUNITY — ${classLabel}`,
    `${addr}`,
    locationLine ? `Location: ${locationLine}` : '',
    `Product Type: ${productTypesDisplay}`,
    '',
    matchReasons.length ? 'WHY THIS MATCHES YOUR BUY BOX:' : '',
    ...textMatchLines,
    '',
    '--- PROPERTY DETAILS ---',
    size ? `Acreage: ${size}` : '',
    price ? `Asking Price: ${price}` : '',
    pricePerAcre ? `Price/Acre: ${pricePerAcre}` : '',
    units ? `Est. Units: ${units}` : '',
    vintage ? `Vintage: ${vintage}` : '',
    zoningDisplay ? `Zoning: ${zoningDisplay}` : '',
    deal.dealType ? `Deal Type: ${deal.dealType}` : '',
    '',
    '--- RENT COMPS ---',
    topRentPerUnit ? `Top Rent/Unit: ${topRentPerUnit}` : '',
    avgRentPerUnit ? `Avg Rent/Unit: ${avgRentPerUnit}` : '',
    topRentPSF ? `Top Rent PSF: ${topRentPSF}` : '',
    avgRentPSF ? `Avg Rent PSF: ${avgRentPSF}` : '',
    compCount ? `# of Comps: ${compCount}` : '',
    '',
    '--- AFFORDABLE HOUSING STATUS ---',
    deal.qctStatus ? `QCT: ${deal.qctStatus}` : '',
    deal.ozStatus ? `Opportunity Zone: ${deal.ozStatus}` : '',
    deal.ddaStatus && deal.ddaStatus !== 'NO' ? `DDA: ${deal.ddaStatus}` : '',
    ddaDetails ? ddaDetails : '',
    '',
    '--- MARKET DEMOGRAPHICS ---',
    deal.censusMedianIncome ? `Median HH Income: $${parseInt(deal.censusMedianIncome).toLocaleString()}` : '',
    deal.censusTotalPopulation ? `Total Population: ${parseInt(deal.censusTotalPopulation).toLocaleString()}` : '',
    deal.censusRenterRate ? `Renter Rate: ${parseFloat(deal.censusRenterRate).toFixed(1)}%` : '',
    deal.censusMedianAge ? `Median Age: ${parseFloat(deal.censusMedianAge).toFixed(1)} yrs` : '',
    '',
    deal.aiExplanatoryNotes ? `AI CLASSIFICATION NOTES:\n${deal.aiExplanatoryNotes}` : '',
    summaryText ? `\nDEAL SUMMARY:\n${summaryText}` : '',
    '',
    deal.excelModelUrl ? `Financial Model (Excel): ${deal.excelModelUrl}` : '',
    deal.investmentMemoUrl ? `Investment Memo (PDF): ${deal.investmentMemoUrl}` : '',
    '',
    'Contact: deals@landlinq.ai',
  ].filter(s => s !== undefined && s !== null && s !== '').join('\n');

  await sendNotificationEmail({
    to: dev.email,
    subject: `New Deal Opportunity: ${addr}`,
    html,
    text: textLines,
  });
}
