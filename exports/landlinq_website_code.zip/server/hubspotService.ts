interface HubSpotContact {
  properties: {
    email: string;
    firstname?: string;
    lastname?: string;
    phone?: string;
    company?: string;
    jobtitle?: string;
    lifecyclestage?: string;
    lead_source?: string;
    hs_lead_status?: string;
    markets_covered?: string;
    years_experience?: string;
    preferred_contact?: string;
  };
}

interface HubSpotDeal {
  properties: {
    dealname: string;
    dealstage: string;
    amount?: string;
    closedate?: string;
    pipeline: string;
    hubspot_owner_id?: string;
    deal_source?: string;
    property_address?: string;
    property_size_acres?: string;
    unit_count?: string;
    asking_price?: string;
    deal_classification?: string;
    zoning?: string;
    sewer_available?: string;
    product_types?: string;
    submission_method?: string;
  };
  associations?: {
    contacts?: number[];
  };
}

// Dynamic brand configuration - update this to automatically change HubSpot tags
const BRAND_NAME = 'LandLinq';
const getBrandTag = () => `${BRAND_NAME} Lead`;
const getBrandPlatform = () => `${BRAND_NAME} Platform`;
const getSourceTag = () => `Source: ${BRAND_NAME}`;
// HubSpot broker sync trigger tag - contacts with this tag will be synced to LandLinq
const getBrokerTag = () => 'LL Sophisticated Broker';

class HubSpotService {
  private baseUrl = 'https://api.hubapi.com';
  private apiKey: string;

  constructor() {
    this.apiKey = process.env.HUBSPOT_API_KEY!;
    if (!this.apiKey) {
      throw new Error('HUBSPOT_API_KEY environment variable is required');
    }
  }

  private async makeRequest(endpoint: string, method: 'GET' | 'POST' | 'PATCH' = 'GET', data?: any) {
    const url = `${this.baseUrl}${endpoint}`;
    const headers = {
      'Authorization': `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
    };

    try {
      const response = await fetch(url, {
        method,
        headers,
        body: data ? JSON.stringify(data) : undefined,
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`HubSpot API error: ${response.status} - ${errorText}`);
      }

      return await response.json();
    } catch (error) {
      console.error('HubSpot API request failed:', error);
      throw error;
    }
  }

  // Create or update a contact (broker)
  async createOrUpdateContact(broker: any): Promise<any> {
    const contactData: HubSpotContact = {
      properties: {
        email: broker.email,
        firstname: broker.firstName || '',
        lastname: broker.lastName || '',
        phone: broker.phone || '',
        company: broker.brokerage || '',
        jobtitle: 'Real Estate Broker',
        lifecyclestage: 'lead',
        lead_source: getBrandPlatform(),
        hs_lead_status: 'NEW',
        markets_covered: broker.marketsCovered || '',
        years_experience: broker.yearsExperience || '',
        preferred_contact: broker.preferredContact || 'email',
      },
    };

    try {
      // Try to find existing contact by email
      const searchResponse = await this.makeRequest(
        `/crm/v3/objects/contacts/search`,
        'POST',
        {
          filterGroups: [{
            filters: [{
              propertyName: 'email',
              operator: 'EQ',
              value: broker.email
            }]
          }]
        }
      );

      if (searchResponse.results && searchResponse.results.length > 0) {
        // Update existing contact
        const contactId = searchResponse.results[0].id;
        return await this.makeRequest(
          `/crm/v3/objects/contacts/${contactId}`,
          'PATCH',
          contactData
        );
      } else {
        // Create new contact
        return await this.makeRequest(
          '/crm/v3/objects/contacts',
          'POST',
          contactData
        );
      }
    } catch (error) {
      console.error('Failed to create/update HubSpot contact:', error);
      throw error;
    }
  }

  // Get a contact by ID (for webhook processing)
  async getContactById(contactId: string): Promise<any> {
    try {
      // Fetch common properties plus hs_tags (plural - HubSpot's tag property)
      const response = await this.makeRequest(
        `/crm/v3/objects/contacts/${contactId}?properties=email,firstname,lastname,phone,company,hs_tags,hs_tag,hubspot_owner_id`,
        'GET'
      );
      return response;
    } catch (error) {
      console.error(`Failed to get HubSpot contact ${contactId}:`, error);
      throw error;
    }
  }

  // Debug: Search for a contact by email and get ALL properties to identify which contains LandLinq tags
  async debugContactByEmail(email: string): Promise<any> {
    try {
      // First search for the contact
      const searchResponse = await this.makeRequest(
        `/crm/v3/objects/contacts/search`,
        'POST',
        {
          filterGroups: [{
            filters: [{
              propertyName: 'email',
              operator: 'EQ',
              value: email
            }]
          }],
          properties: [
            'email', 'firstname', 'lastname', 'phone', 'company', 'hubspot_owner_id',
            'radio_select', 'hs_tags', 'hs_tag', 'contact_tags', 'tags',
            'hs_content_membership_status', 'hs_marketable_status',
            'lifecyclestage', 'hs_lead_status'
          ]
        }
      );

      if (searchResponse.results && searchResponse.results.length > 0) {
        const contact = searchResponse.results[0];
        console.log(`🔍 [DEBUG] Contact ${email} properties:`, JSON.stringify(contact.properties, null, 2));
        return contact;
      } else {
        console.log(`🔍 [DEBUG] Contact ${email} not found`);
        return null;
      }
    } catch (error) {
      console.error(`Failed to debug contact ${email}:`, error);
      throw error;
    }
  }

  // Create a deal for property submission
  async createDeal(deal: any, contactId?: string): Promise<any> {
    const dealData: HubSpotDeal = {
      properties: {
        dealname: `${deal.address} - Property Deal`,
        dealstage: this.mapDealStage(deal.status || deal.classification),
        amount: deal.askingPrice ? deal.askingPrice.toString() : undefined,
        pipeline: 'default', // You may want to create a custom pipeline
        deal_source: getBrandPlatform(),
        property_address: deal.address,
        property_size_acres: deal.sizeAcres?.toString(),
        unit_count: deal.unitCount?.toString(),
        asking_price: deal.askingPrice?.toString(),
        deal_classification: deal.classification,
        zoning: deal.zoning,
        sewer_available: deal.sewerAvailable === true ? 'Yes' : deal.sewerAvailable === false ? 'No' : 'Unknown',
        product_types: Array.isArray(deal.productTypes) ? deal.productTypes.join(', ') : '',
        submission_method: deal.submissionMethod,
      },
    };

    // Associate with contact if provided
    if (contactId) {
      dealData.associations = {
        contacts: [parseInt(contactId)]
      };
    }

    try {
      return await this.makeRequest(
        '/crm/v3/objects/deals',
        'POST',
        dealData
      );
    } catch (error) {
      console.error('Failed to create HubSpot deal:', error);
      throw error;
    }
  }

  // Map deal status/classification to HubSpot deal stages
  private mapDealStage(status: string): string {
    const stageMapping: { [key: string]: string } = {
      'pending_review': 'qualifiedtobuy', // Qualified to buy
      'under_review': 'presentationscheduled', // Presentation scheduled
      'high_priority': 'decisionmakerboughtin', // Decision maker bought-in
      'green': 'decisionmakerboughtin',
      'potentially': 'qualifiedtobuy',
      'yellow': 'qualifiedtobuy',
      'clear_no': 'closedlost', // Closed lost
      'red': 'closedlost',
      'approved': 'closedwon', // Closed won
      'rejected': 'closedlost',
    };

    return stageMapping[status] || 'appointmentscheduled'; // Default stage
  }

  // Update deal status
  async updateDeal(dealId: string, updates: any): Promise<any> {
    const updateData = {
      properties: {
        dealstage: this.mapDealStage(updates.status || updates.classification),
        deal_classification: updates.classification,
        ...updates
      }
    };

    try {
      return await this.makeRequest(
        `/crm/v3/objects/deals/${dealId}`,
        'PATCH',
        updateData
      );
    } catch (error) {
      console.error('Failed to update HubSpot deal:', error);
      throw error;
    }
  }

  // Add tags to a contact or deal
  async addTags(objectId: string, objectType: 'contact' | 'deal', tags: string[]): Promise<any> {
    try {
      const tagData = {
        inputs: tags.map(tag => ({
          id: objectId,
          properties: {
            [`hs_${objectType}_tags`]: tag
          }
        }))
      };

      return await this.makeRequest(
        `/crm/v3/objects/${objectType}s/batch/update`,
        'POST',
        tagData
      );
    } catch (error) {
      console.error(`Failed to add tags to HubSpot ${objectType}:`, error);
      // Don't throw - tagging failure shouldn't stop the main process
    }
  }

  // Create a note/activity
  async createNote(objectId: string, objectType: 'contact' | 'deal', noteContent: string): Promise<any> {
    const noteData = {
      properties: {
        hs_note_body: noteContent,
        hs_timestamp: new Date().toISOString(),
      },
      associations: {
        [objectType === 'contact' ? 'contacts' : 'deals']: [parseInt(objectId)]
      }
    };

    try {
      return await this.makeRequest(
        '/crm/v3/objects/notes',
        'POST',
        noteData
      );
    } catch (error) {
      console.error('Failed to create HubSpot note:', error);
      throw error;
    }
  }

  // Sync broker registration
  async syncBrokerRegistration(broker: any): Promise<{ contactId: string }> {
    try {
      const contact = await this.createOrUpdateContact(broker);
      
      // Create a note about the registration
      const noteContent = `Broker registered on ${getBrandPlatform()}.
        
Markets Covered: ${broker.marketsCovered || 'N/A'}
Years Experience: ${broker.yearsExperience || 'N/A'}
Brokerage: ${broker.brokerage || 'N/A'}
Preferred Contact: ${broker.preferredContact || 'Email'}
Registration Date: ${new Date().toLocaleDateString()}`;

      await this.createNote(contact.id, 'contact', noteContent);

      // Add comprehensive LandLinq tags to identify source
      await this.addTags(contact.id, 'contact', [
        getSourceTag(),        // "Source: LandLinq"
        getBrokerTag(),        // "LL Sophisticated Broker"
        'Real Estate Lead'     // General category
      ]);

      return { contactId: contact.id };
    } catch (error) {
      console.error('Failed to sync broker registration to HubSpot:', error);
      throw error;
    }
  }

  // Tag a contact as "Engaged" when they open/click emails
  // This allows sales team to prioritize follow-up with responsive contacts
  async tagContactEngaged(email: string, engagementType: 'opened' | 'clicked' | 'replied'): Promise<boolean> {
    try {
      console.log(`🎯 [HUBSPOT-ENGAGE] Tagging ${email} as engaged (${engagementType})`);
      
      // First find the contact by email
      const searchResponse = await this.makeRequest(
        `/crm/v3/objects/contacts/search`,
        'POST',
        {
          filterGroups: [{
            filters: [{
              propertyName: 'email',
              operator: 'EQ',
              value: email
            }]
          }]
        }
      );

      if (!searchResponse.results || searchResponse.results.length === 0) {
        console.log(`🎯 [HUBSPOT-ENGAGE] Contact not found in HubSpot: ${email}`);
        return false;
      }

      const contactId = searchResponse.results[0].id;
      const existingTags = searchResponse.results[0].properties?.hs_tags || '';
      
      // Determine which engagement tag to add
      const engagementTag = engagementType === 'clicked' ? 'LL Email Clicked' 
                          : engagementType === 'replied' ? 'LL Email Replied'
                          : 'LL Email Opened';
      
      // Check if already tagged to avoid duplicates
      if (existingTags.toLowerCase().includes(engagementTag.toLowerCase())) {
        console.log(`🎯 [HUBSPOT-ENGAGE] Contact ${email} already has "${engagementTag}" tag`);
        return true;
      }

      // Add the engagement tag (hs_tags is comma-separated in HubSpot)
      const newTags = existingTags ? `${existingTags},${engagementTag}` : engagementTag;
      
      await this.makeRequest(
        `/crm/v3/objects/contacts/${contactId}`,
        'PATCH',
        {
          properties: {
            hs_tags: newTags
          }
        }
      );

      // Also add a note about the engagement
      const noteContent = `📧 Email ${engagementType} - ${new Date().toLocaleString()}`;
      await this.createNote(contactId, 'contact', noteContent);

      console.log(`✅ [HUBSPOT-ENGAGE] Successfully tagged ${email} as "${engagementTag}"`);
      return true;
    } catch (error) {
      console.error(`❌ [HUBSPOT-ENGAGE] Failed to tag contact ${email}:`, error);
      return false;
    }
  }

  // Sync deal submission
  async syncDealSubmission(deal: any, brokerEmail: string): Promise<{ dealId: string }> {
    try {
      // First, find or create the broker contact
      let contactId: string | undefined;

      try {
        const searchResponse = await this.makeRequest(
          `/crm/v3/objects/contacts/search`,
          'POST',
          {
            filterGroups: [{
              filters: [{
                propertyName: 'email',
                operator: 'EQ',
                value: brokerEmail
              }]
            }]
          }
        );

        if (searchResponse.results && searchResponse.results.length > 0) {
          contactId = searchResponse.results[0].id;
        }
      } catch (error) {
        console.error('Could not find contact for deal:', error);
      }

      // Create the deal
      const hubspotDeal = await this.createDeal(deal, contactId);

      // Create a note with deal details
      const noteContent = `New property deal submitted via ${getBrandPlatform()}.
        
Property Address: ${deal.address}
Asking Price: ${deal.askingPrice ? `$${deal.askingPrice}` : 'Not specified'}
Size: ${deal.sizeAcres ? `${deal.sizeAcres} acres` : 'Not specified'}
Unit Count: ${deal.unitCount || 'Not specified'}
Zoning: ${deal.zoning || 'Not specified'}
Sewer Available: ${deal.sewerAvailable ? 'Yes' : 'No'}
Classification: ${deal.classification || 'Pending'}
Submission Method: ${deal.submissionMethod}
Submission Date: ${new Date().toLocaleDateString()}

Additional Notes: ${deal.brokerNotes || 'None'}`;

      await this.createNote(hubspotDeal.id, 'deal', noteContent);

      // Add comprehensive LandLinq tags to identify source  
      await this.addTags(hubspotDeal.id, 'deal', [
        getSourceTag(),           // "Source: LandLinq"
        'Land Acquisition Deal',  // Deal type
        `${deal.submissionMethod} Submission`  // How it was submitted
      ]);

      return { dealId: hubspotDeal.id };
    } catch (error) {
      console.error('Failed to sync deal submission to HubSpot:', error);
      throw error;
    }
  }

  // Search for contacts with a specific tag using HubSpot Search API (more efficient)
  // For Multiple checkbox fields, HubSpot stores values as semicolon-separated strings
  async searchContactsByTag(tagValue: string): Promise<any[]> {
    const allContacts: any[] = [];
    let after: number | undefined = undefined;
    const maxPages = 10;
    let pageCount = 0;

    try {
      // CASE-INSENSITIVE SEARCH: HubSpot API is case-sensitive but UI shows different casing
      // Try multiple case variations: original, lowercase "known/unknown", and full lowercase
      const caseVariations = [
        tagValue,
        tagValue.replace(' Known ', ' known ').replace(' Unknown ', ' unknown '),
        tagValue.toLowerCase(),
      ].filter((v, i, arr) => arr.indexOf(v) === i); // Remove duplicates
      
      for (const caseVariant of caseVariations) {
        allContacts.length = 0;
        after = undefined;
        pageCount = 0;
        
        do {
          const searchBody = {
            filterGroups: [{
              filters: [{
                propertyName: 'radio_select',
                operator: 'EQ',
                value: caseVariant
              }]
            }],
            properties: ['email', 'firstname', 'lastname', 'phone', 'company', 'radio_select', 'hubspot_owner_id'],
            limit: 100,
            ...(after && { after })
          };
          
          const response = await this.makeRequest('/crm/v3/objects/contacts/search', 'POST', searchBody);
          
          if (response.results) {
            allContacts.push(...response.results);
          }
          
          after = response.paging?.next?.after;
          pageCount++;
          
        } while (after && pageCount < maxPages);
        
        if (allContacts.length > 0) {
          console.log(`   📊 Search found ${allContacts.length} contacts with EQ:"${caseVariant}" (${pageCount} pages)`);
          return allContacts;
        }
      }

      console.log(`   📊 Search found ${allContacts.length} contacts with tag "${tagValue}" (tried ${caseVariations.length} case variations)`);
      
      // If search returns 0, fall back to pagination to check all contacts manually
      if (allContacts.length === 0) {
        console.log('   🔄 Trying pagination fallback to manually check tags...');
        return this.searchAllContactsPaginated();
      }
      
      return allContacts;
    } catch (error) {
      console.error('Failed to search HubSpot contacts by tag:', error);
      // Fallback to pagination method if search fails
      console.log('   ⚠️ Falling back to pagination method...');
      return this.searchAllContactsPaginated();
    }
  }
  
  // Search for all contacts with pagination - used for polling sync (fallback)
  async searchAllContactsPaginated(): Promise<any[]> {
    const allContacts: any[] = [];
    let after: string | undefined = undefined;
    const pageSize = 100;
    const maxPages = 50; // Increased limit: fetch up to 5000 contacts to find recently tagged ones
    let pageCount = 0;

    try {
      do {
        // Fetch multiple possible tag property names - HubSpot uses different names for tags
        // "Contact Tags" in this account = "radio_select" internal name
        const tagProperties = 'radio_select,hs_tags,hs_tag,contact_tags,tags';
        const url = after 
          ? `/crm/v3/objects/contacts?limit=${pageSize}&after=${after}&properties=email,firstname,lastname,phone,company,${tagProperties},hubspot_owner_id`
          : `/crm/v3/objects/contacts?limit=${pageSize}&properties=email,firstname,lastname,phone,company,${tagProperties},hubspot_owner_id`;
        
        const response = await this.makeRequest(url, 'GET');
        
        if (response.results) {
          allContacts.push(...response.results);
        }
        
        after = response.paging?.next?.after;
        pageCount++;
        
      } while (after && pageCount < maxPages);

      console.log(`   📊 Fetched ${allContacts.length} contacts from HubSpot (${pageCount} pages)`);
      return allContacts;
    } catch (error) {
      console.error('Failed to search HubSpot contacts:', error);
      throw error;
    }
  }

  // Poll for contacts with a specific tag that haven't been synced yet
  async pollForTaggedContacts(
    targetTag: string,
    alreadySyncedIds: string[]
  ): Promise<Array<{
    hubspotContactId: string;
    email: string;
    firstName: string;
    lastName: string;
    phone: string;
    company: string;
    hubspotOwnerId: string | null;
  }>> {
    console.log(`🔍 [HUBSPOT-POLL] Searching for contacts with tag: "${targetTag}"`);
    
    try {
      // Use search API to find contacts with the specific tag (much more efficient)
      const contacts = await this.searchContactsByTag(targetTag);
      
      const matchingContacts: Array<{
        hubspotContactId: string;
        email: string;
        firstName: string;
        lastName: string;
        phone: string;
        company: string;
        hubspotOwnerId: string | null;
      }> = [];

      for (const contact of contacts) {
        const contactId = contact.id;
        
        // Skip if already synced
        if (alreadySyncedIds.includes(contactId)) {
          continue;
        }

        // Check if contact has the target tag - check multiple possible property names
        // HubSpot uses custom property names - "Contact Tags" = "radio_select" in this account
        const possibleTags = [
          contact.properties?.radio_select,  // Custom "Contact Tags" property
          contact.properties?.hs_tags,
          contact.properties?.hs_tag,
          contact.properties?.contact_tags,
          contact.properties?.tags,
        ].filter(Boolean).join(';');
        
        // Debug logging removed - was flooding logs with 5000+ lines per poll cycle
        
        const tagList = possibleTags.split(';').map((t: string) => t.trim().toLowerCase());
        
        // EXACT MATCH ONLY: Partial matching was causing 2600+ false positives
        // Tags must match exactly (case-insensitive) to prevent cross-tag pollution
        const hasExactMatch = tagList.includes(targetTag.toLowerCase());
        
        if (hasExactMatch) {
          const email = contact.properties?.email;
          
          // Skip contacts without email
          if (!email) {
            console.log(`   ⚠️ Contact ${contactId} has tag but no email, skipping`);
            continue;
          }

          matchingContacts.push({
            hubspotContactId: contactId,
            email: email,
            firstName: contact.properties?.firstname || '',
            lastName: contact.properties?.lastname || '',
            phone: contact.properties?.phone || '',
            company: contact.properties?.company || '',
            hubspotOwnerId: contact.properties?.hubspot_owner_id || null,
          });

          console.log(`   ✅ Found new tagged contact: ${email} (Owner: ${contact.properties?.hubspot_owner_id || 'none'})`);
        }
      }

      console.log(`🔍 [HUBSPOT-POLL] Found ${matchingContacts.length} new contacts with tag "${targetTag}"`);
      return matchingContacts;
    } catch (error) {
      console.error('Failed to poll HubSpot for tagged contacts:', error);
      throw error;
    }
  }

  // Check if HubSpot API connection is working
  async testConnection(): Promise<{ connected: boolean; accountInfo?: any; error?: string }> {
    try {
      // Try to fetch a single contact to verify API key works
      const response = await this.makeRequest(
        '/crm/v3/objects/contacts?limit=1&properties=email',
        'GET'
      );
      return { 
        connected: true, 
        accountInfo: { contactCount: response.total || (response.results?.length || 0) }
      };
    } catch (error: any) {
      return { 
        connected: false, 
        error: error.message || 'Failed to connect to HubSpot' 
      };
    }
  }
}

export { HubSpotService };