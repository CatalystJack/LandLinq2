import { db } from './db';
import { sql } from 'drizzle-orm';

const GRAPH_SEND_URL = 'https://graph.microsoft.com/v1.0/me/sendMail';
const TOKEN_URL = (tenantId: string) =>
  `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;

export interface MicrosoftTokens {
  accessToken: string;
  refreshToken?: string;
  expiresAt: Date;
}

export interface MicrosoftSendOptions {
  to: string;
  subject: string;
  htmlBody: string;
  attachments?: Array<{
    filename: string;
    contentType: string;
    contentBytes: string; // base64
  }>;
}

/**
 * Refresh a Microsoft OAuth access token using a refresh token.
 */
export async function refreshMicrosoftToken(refreshToken: string): Promise<MicrosoftTokens> {
  const clientId     = process.env.MICROSOFT_CLIENT_ID;
  const clientSecret = process.env.MICROSOFT_CLIENT_SECRET;
  const tenantId     = process.env.MICROSOFT_TENANT_ID || 'common';

  if (!clientId || !clientSecret) {
    throw new Error('MICROSOFT_CLIENT_ID / MICROSOFT_CLIENT_SECRET not configured');
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20_000);

  let response: Response;
  try {
    response = await fetch(TOKEN_URL(tenantId), {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      signal: controller.signal,
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        refresh_token: refreshToken,
        grant_type: 'refresh_token',
        scope: 'https://graph.microsoft.com/Mail.Send offline_access',
      }),
    });
  } finally {
    clearTimeout(timeout);
  }

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`Microsoft token refresh failed (${response.status}): ${body}`);
  }

  const tokens = await response.json() as {
    access_token: string;
    refresh_token?: string;
    expires_in: number;
  };

  return {
    accessToken:  tokens.access_token,
    refreshToken: tokens.refresh_token,
    expiresAt:    new Date(Date.now() + tokens.expires_in * 1_000),
  };
}

/**
 * Send an email via Microsoft Graph API using a valid access token.
 * Throws on failure — caller is responsible for fallback logic.
 */
export async function sendEmailViaMicrosoft(
  accessToken: string,
  opts: MicrosoftSendOptions,
): Promise<void> {
  const graphAttachments = (opts.attachments || []).map(att => ({
    '@odata.type': '#microsoft.graph.fileAttachment',
    name: att.filename,
    contentType: att.contentType,
    contentBytes: att.contentBytes,
  }));

  const body: Record<string, any> = {
    message: {
      subject: opts.subject,
      body: {
        contentType: 'HTML',
        content: opts.htmlBody,
      },
      toRecipients: [{ emailAddress: { address: opts.to } }],
      ...(graphAttachments.length > 0 && { attachments: graphAttachments }),
    },
    saveToSentItems: true,
  };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);

  let response: Response;
  try {
    response = await fetch(GRAPH_SEND_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      signal: controller.signal,
      body: JSON.stringify(body),
    });
  } finally {
    clearTimeout(timeout);
  }

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Microsoft Graph send failed (${response.status}): ${errorText}`);
  }
}

/**
 * Convenience helper: refresh token if expiring soon, then send.
 * Updates the `outreach_senders` row if a refresh was performed.
 * Returns the send method used ('microsoft').
 */
export async function sendDripEmailViaMicrosoft(enrollment: {
  id: string;
  contact_email: string;
  sender_id: string;
  microsoft_access_token: string;
  microsoft_refresh_token: string | null;
  microsoft_token_expiry: Date | string | null;
}, opts: { subject: string; htmlBody: string; attachments?: Array<{ filename: string; contentType: string; contentBytes: string }> }): Promise<void> {
  let accessToken = enrollment.microsoft_access_token;
  const tokenExpiry = enrollment.microsoft_token_expiry
    ? new Date(enrollment.microsoft_token_expiry)
    : null;

  // Refresh if expired or expiring within the next 5 minutes
  const needsRefresh =
    tokenExpiry && tokenExpiry <= new Date(Date.now() + 5 * 60 * 1_000);

  if (needsRefresh && enrollment.microsoft_refresh_token) {
    try {
      const newTokens = await refreshMicrosoftToken(enrollment.microsoft_refresh_token);
      accessToken = newTokens.accessToken;

      await db.execute(sql`
        UPDATE outreach_senders
        SET microsoft_access_token = ${newTokens.accessToken},
            microsoft_refresh_token = ${newTokens.refreshToken ?? enrollment.microsoft_refresh_token},
            microsoft_token_expiry  = ${newTokens.expiresAt},
            updated_at              = NOW()
        WHERE id = ${enrollment.sender_id}
      `);
      console.log(`   🔄 [DRIP] Microsoft token refreshed for sender ${enrollment.sender_id}`);
    } catch (refreshErr: any) {
      console.error(`   ❌ [DRIP] Token refresh failed for sender ${enrollment.sender_id}:`, refreshErr.message);
      throw refreshErr;
    }
  }

  await sendEmailViaMicrosoft(accessToken, {
    to: enrollment.contact_email,
    subject: opts.subject,
    htmlBody: opts.htmlBody,
    ...(opts.attachments && opts.attachments.length > 0 && { attachments: opts.attachments }),
  });
}
