import { storage } from "./storage";
import { emailService, sendNotificationEmail } from "./emailService";
import { TemplateService } from "./templateService";

export class EmailAutomationService {
  // Send deal submission confirmation using standardized templates from outreach management
  async sendDealSubmissionConfirmation(dealId: string, brokerEmail: string): Promise<void> {
    try {
      const deal = await storage.getDealById(dealId);
      const broker = await storage.getBrokerByEmail(brokerEmail);
      
      if (!deal || !broker) {
        console.error("Deal or broker not found for confirmation email");
        return;
      }

      // ✅ USE STANDARDIZED TEMPLATE SERVICE - NO CUSTOM HTML
      // CRITICAL FIX (Nov 22, 2025): Add absolute dashboard URL for deal link
      const dealUrl = `https://landlinq.ai/messaging/deals/${deal.id}`;
      
      // Jan 29, 2026: Use CONCISE aiExplanatoryNotes for acceptance reason (not verbose comparableNotes)
      // aiExplanatoryNotes = "YELLOW: 5 qualifying comparables found ($2065/unit avg)..."
      const acceptanceReason = (deal as any).aiExplanatoryNotes || '';
      
      const template = await TemplateService.getEmailTemplate('deal_submitted', {
        brokerName: `${broker.firstName} ${broker.lastName}`,
        propertyAddress: deal.address,
        address: deal.address,
        dealId: deal.id || '',
        dealUrl: dealUrl, // Add absolute URL for deal link in email - correct route is /messaging/deals/
        status: 'Under Review',
        submissionMethod: deal.submissionMethod || 'FORM',
        // Include acceptance reason for high priority deals
        classification: (deal as any).classification || '',
        classificationNotes: acceptanceReason,
        acceptanceReason: acceptanceReason
      });

      if (!template) {
        console.error('No deal_submitted template found in outreach management');
        return;
      }

      const htmlContent = template.html || template.content;
      const emailSubject = template.subject;

      // Send HTML email using sendNotificationEmail
      await sendNotificationEmail({
        to: brokerEmail,
        subject: emailSubject,
        html: htmlContent,
        type: 'deal_alert',
        priority: 'medium'
      });

      // Log communication with actual email content for analyst review
      // Convert HTML to plain text for communication log while preserving content
      const plainTextVersion = htmlContent
        .replace(/<[^>]*>/g, '') // Remove HTML tags
        .replace(/&nbsp;/g, ' ') // Replace non-breaking spaces
        .replace(/&amp;/g, '&') // Replace HTML entities
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/\s+/g, ' ') // Collapse multiple spaces
        .trim();
      
      await storage.createCommunication({
        brokerId: broker.id,
        relatedDealId: dealId,
        channel: "email",
        direction: "outbound",
        rawText: plainTextVersion, // Store the actual content for analyst review
        subject: emailSubject,
        message: plainTextVersion, // Store the actual message content
        recipientEmail: brokerEmail,
        status: "resolved" // Deal confirmation, not a follow-up for missing info
      });

      console.log(`Deal submission confirmation sent to ${brokerEmail} using custom template`);
    } catch (error) {
      console.error("Failed to send deal submission confirmation:", error);
    }
  }

  // Send deal status update notification
  async sendDealStatusUpdate(dealId: string, newStatus: string): Promise<void> {
    try {
      const deal = await storage.getDealById(dealId);
      if (!deal) {
        console.error("Deal not found for status update email");
        return;
      }

      const broker = await storage.getBrokerById(deal.brokerId);
      if (!broker) {
        console.error("Broker not found for deal status update");
        return;
      }

      const statusMessages = {
        'approved': {
          subject: `🎉 Great News! Your Property Has Been Approved - ${deal.address}`,
          message: `
Hello ${broker.firstName},

Excellent news! Your property submission at ${deal.address} has been approved for acquisition consideration.

Our team is very interested in this property and would like to move forward with the next steps.

Someone from our acquisition team will contact you within 24 hours to discuss:
- Purchase terms and timeline
- Due diligence requirements
- Closing process

You can view the full details in your dashboard: https://landlinq.ai/dashboard

Thank you for bringing us this opportunity!

Best regards,
The LandLinq Acquisition Team
`
        },
        'rejected': {
          subject: `Update on Your Property Submission - ${deal.address}`,
          message: `
Hello ${broker.firstName},

Thank you for submitting your property at ${deal.address} for our review.

After careful consideration by our acquisition team, we have determined that this property does not align with our current acquisition criteria and strategic focus.

${deal.rejectionReason ? `
📝 ANALYST FEEDBACK:
${deal.rejectionReason}

This feedback is provided to help you understand our criteria better and improve future submissions.

` : ''}This decision doesn't reflect on the quality of the property or your submission. Our criteria are very specific based on current market conditions and portfolio needs.

We encourage you to submit other properties that might be a better fit for our current requirements.

You can view our current acquisition criteria at: https://landlinq.ai/criteria

Thank you for thinking of LandLinq!

Best regards,
The LandLinq Team
`
        },
        'high_priority': {
          subject: `🔥 High Priority Status - ${deal.address}`,
          message: `
Hello ${broker.firstName},

Your property submission at ${deal.address} has been marked as HIGH PRIORITY by our acquisition team!

This means:
- Your property meets multiple key criteria for our acquisition strategy
- It will receive expedited review and response
- An acquisition specialist will contact you within 12 hours

Please ensure you're available to discuss this opportunity promptly.

Best regards,
The LandLinq Priority Acquisitions Team
`
        }
      };

      const emailTemplate = statusMessages[newStatus as keyof typeof statusMessages];
      if (!emailTemplate) {
        console.log(`No email template for status: ${newStatus}`);
        return;
      }

      await sendNotificationEmail({
        to: broker.email || '',
        subject: emailTemplate.subject,
        text: emailTemplate.message,
        type: 'deal_status_update',
        priority: 'medium'
      });

      // Log communication
      await storage.createCommunication({
        brokerId: broker.id,
        relatedDealId: dealId,
        channel: "email",
        direction: "outbound",
        rawText: emailTemplate.message,
        subject: emailTemplate.subject,
        message: emailTemplate.message,
        recipientEmail: broker.email,
        status: "resolved" // Status update, not a follow-up for missing info
      });

      console.log(`Deal status update (${newStatus}) sent to ${broker.email}`);
    } catch (error) {
      console.error("Failed to send deal status update:", error);
    }
  }

  // Send weekly digest to analysts
  async sendWeeklyAnalystDigest(): Promise<void> {
    try {
      const teamMembers = await storage.getCatalystTeamMembers();
      const recentDeals = await storage.getAllDealsWithBrokers();
      
      // Filter deals from last 7 days
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      
      const weeklyDeals = recentDeals.filter(deal => 
        deal.createdAt && new Date(deal.createdAt) >= weekAgo
      );

      if (weeklyDeals.length === 0) {
        console.log("No new deals this week, skipping digest");
        return;
      }

      const subject = `Weekly LandLinq Digest - ${weeklyDeals.length} New Submissions`;
      const text = `
Weekly LandLinq Activity Summary
===============================

This week: ${weeklyDeals.length} new property submissions

High Priority Deals (${weeklyDeals.filter(d => d.classification === 'green').length}):
${weeklyDeals.filter(d => d.classification === 'green').map(d => 
  `• ${d.address} - ${d.sizeAcres} acres - $${d.askingPrice} - ${d.broker.firstName} ${d.broker.lastName}`
).join('\n')}

Under Review (${weeklyDeals.filter(d => d.classification === 'yellow').length}):
${weeklyDeals.filter(d => d.classification === 'yellow').map(d => 
  `• ${d.address} - ${d.sizeAcres} acres - ${d.broker.firstName} ${d.broker.lastName}`
).join('\n')}

Pipeline Summary:
- Total Active Deals: ${recentDeals.length}
- Approved This Week: ${weeklyDeals.filter(d => d.status === 'approved').length}
- High Priority: ${recentDeals.filter(d => d.classification === 'green').length}
- Under Review: ${recentDeals.filter(d => d.classification === 'yellow').length}

View full dashboard: https://landlinq.ai/analyst-dashboard

Best regards,
LandLinq Analytics Engine
`;

      // Send to all team members
      for (const member of teamMembers) {
        await sendNotificationEmail({
          to: member.email,
          subject,
          text,
          type: 'weekly_digest',
          priority: 'low'
        });
      }

      console.log(`Weekly digest sent to ${teamMembers.length} team members`);
    } catch (error) {
      console.error("Failed to send weekly analyst digest:", error);
    }
  }

  // Commission payment notification (disabled)
  async sendCommissionPaymentNotification(brokerId: string, amount: number, dealAddress: string): Promise<void> {
    try {
      const broker = await storage.getBrokerById(brokerId);
      if (!broker) {
        console.error("Broker not found for commission tracking");
        return;
      }

      // Log commission tracking only (no automated notifications)
      console.log(`Commission payment tracked for ${broker.firstName} ${broker.lastName}`);
      console.log(`Amount: $${amount.toLocaleString()} for ${dealAddress}`);
      console.log("Automated commission notifications disabled");

    } catch (error) {
      console.error("Failed to track commission payment:", error);
    }
  }
}

export const emailAutomationService = new EmailAutomationService();